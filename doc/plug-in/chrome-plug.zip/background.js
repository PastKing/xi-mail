/** Xi-Mail 后台入口：会话管理、消息分发、邮件缓存与通知。 */
import {
  ApiError,
  loadSettings,
  chromeLocalStorage,
  normalizeOrigin,
  XiMailClient,
  saveSettings,
  extractVerificationCode,
} from './assets/settings-storage.js'

/**
 * 会话存储配额：串行写入并按使用顺序淘汰缓存，保留必要会话数据。
 */
// 缓存与必要会话数据共享配额；仅允许淘汰缓存。
const CACHE_PREFIX = 'mailCache:'
const CACHE_BUDGET_BYTES = 6 * 1024 * 1024
const MAX_CACHE_ENTRY_BYTES = 1024 * 1024
const RESERVE_BYTES = 2 * 1024 * 1024
const QUOTA_BYTES = 10 * 1024 * 1024
const touched = new Map()
let clock = 0
let queue = Promise.resolve()

function updateSessionStore(action) {
  const result = queue.then(action, action)
  queue = result.catch(() => {})
  return result
}

function touchCache(key) {
  touched.set(key, ++clock)
}

function estimate(key, value) {
  return 256 + key.length * 2 + JSON.stringify(value).length * 2
}

async function measured(keys, entries) {
  if (!keys.length) return 0
  if (chrome.storage.session.getBytesInUse) return chrome.storage.session.getBytesInUse(keys)
  return keys.reduce((sum, key) => sum + estimate(key, entries[key]), 0)
}

async function trim(entries, incoming = 0) {
  const keys = Object.keys(entries)
  for (const key of touched.keys()) if (!(key in entries)) touched.delete(key)
  const cacheKeys = keys
    .filter((key) => key.startsWith(CACHE_PREFIX))
    .sort((a, b) => (touched.get(a) || 0) - (touched.get(b) || 0))
  const essentialBytes = await measured(
    keys.filter((key) => !key.startsWith(CACHE_PREFIX)),
    entries
  )
  const limit = Math.max(
    0,
    Math.min(CACHE_BUDGET_BYTES, QUOTA_BYTES - RESERVE_BYTES - essentialBytes)
  )
  let size = await measured(cacheKeys, entries)
  const remove = []
  for (const key of cacheKeys) {
    if (size + incoming <= limit) break
    size -= await measured([key], entries)
    remove.push(key)
    touched.delete(key)
  }
  if (remove.length) await chrome.storage.session.remove(remove)
}

function compactSessionCache() {
  return updateSessionStore(async () => {
    await trim(await chrome.storage.session.get(null))
  })
}

// 仅在 updateSessionStore 队列内调用；替换失败或超限时不能保留旧缓存。
async function storeCacheEntry(key, value) {
  const size = estimate(key, value)
  await chrome.storage.session.remove([key])
  touched.delete(key)
  if (size > MAX_CACHE_ENTRY_BYTES) return
  const entries = await chrome.storage.session.get(null)
  await trim(entries, size)
  const essential = Object.keys(entries).filter((name) => !name.startsWith(CACHE_PREFIX))
  if ((await measured(essential, entries)) + size + RESERVE_BYTES > QUOTA_BYTES) return
  try {
    await chrome.storage.session.set({ [key]: value })
    touchCache(key)
    // Chrome 的对象开销与 JSON 大小不同，还需按浏览器实测值限制配额。
    await trim(await chrome.storage.session.get(null))
  } catch {
    await chrome.storage.session.remove([key])
    touched.delete(key)
  }
}

function saveSessionData(items) {
  return updateSessionStore(async () => {
    try {
      await chrome.storage.session.set(items)
    } catch (error) {
      if (!/quota/i.test(error instanceof Error ? error.message : String(error))) throw error
      const keys = Object.keys(await chrome.storage.session.get(null)).filter((key) =>
        key.startsWith(CACHE_PREFIX)
      )
      if (!keys.length) throw error
      await chrome.storage.session.remove(keys)
      keys.forEach((key) => touched.delete(key))
      await chrome.storage.session.set(items)
    }
  })
}

/**
 * 运行时会话存储：读取、保存和清理当前登录会话。
 */
const KEYS = ['sessionToken', 'sessionUser', 'sessionApiOrigin', 'sessionId', 'sessionProfileId']

async function loadSessionAuth(storage) {
  const stored = await storage.get([...KEYS])
  const token = stored.sessionToken
  const user = stored.sessionUser
  const apiOrigin = stored.sessionApiOrigin
  const id = stored.sessionId
  if (typeof id !== 'string' || !id) return null
  if (typeof token !== 'string' || !token) return null
  if (typeof apiOrigin !== 'string' || !apiOrigin) return null
  if (typeof user !== 'object' || user === null) return null
  return {
    id,
    token,
    user: user,
    apiOrigin,
    profileId: typeof stored.sessionProfileId === 'string' ? stored.sessionProfileId : undefined,
  }
}

async function saveSessionAuth(storage, auth) {
  await storage.set({
    sessionId: auth.id,
    sessionProfileId: auth.profileId || auth.id,
    sessionToken: auth.token,
    sessionUser: auth.user,
    sessionApiOrigin: auth.apiOrigin,
  })
}

async function clearSessionAuth(storage) {
  await storage.remove([...KEYS])
}

function chromeSessionStorage() {
  return {
    get: (keys) => chrome.storage.session.get(keys),
    set: saveSessionData,
    remove: (keys) => chrome.storage.session.remove(keys),
  }
}

/**
 * 通知轮询纯逻辑：推进邮件水位、筛选新邮件并生成通知摘要。
 */
function nextPollState(state, fetched) {
  const maxId = fetched.reduce((max, item) => Math.max(max, Number(item.emailId) || 0), 0)
  if (!state.initialized) {
    return { state: { watermark: Math.max(state.watermark, maxId), initialized: true }, fresh: [] }
  }
  const fresh = fetched.filter((item) => Number(item.emailId) > state.watermark)
  return { state: { watermark: Math.max(state.watermark, maxId), initialized: true }, fresh }
}

/** 由 fresh 邮件构造通知文案（最多展示第一封） */
function buildNotification(fresh) {
  if (!fresh.length) return { notified: false, freshCount: 0 }
  const first = fresh[0]
  const sender = first.name || first.sendEmail || '未知发件人'
  const subject = first.subject || '（无主题）'
  return {
    notified: true,
    freshCount: fresh.length,
    title: fresh.length === 1 ? 'Xi-Mail 收到新邮件' : `收到 ${fresh.length} 封新邮件`,
    message: `${sender} · ${subject}`,
  }
}

/**
 * 通知导航：点击通知后打开或聚焦对应站点的收件箱。
 */
/** xi-mail Web 根路径会重定向到 /inbox。 */
const INBOX_ROUTE = '/inbox'

function inboxTarget(value, route = INBOX_ROUTE) {
  if (typeof value !== 'string') return null
  try {
    const url = new URL(value)
    const localHttp = url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname)
    if (url.protocol !== 'https:' && !localHttp) return null
    if (url.username || url.password) return null
    const target = new URL(route, url.origin)
    if (target.origin !== url.origin || !target.pathname.startsWith('/')) return null
    return {
      destination: target.toString(),
      urlPattern: `${url.protocol}//${url.hostname}/*`,
    }
  } catch {
    return null
  }
}

function isInboxTab(tab, destination) {
  if (!tab.url) return false
  try {
    const current = new URL(tab.url)
    const target = new URL(destination)
    const path = (value) => value.replace(/\/+$/, '') || '/'
    return (
      current.origin === target.origin &&
      (path(current.pathname) === path(target.pathname) ||
        (path(current.pathname) === '/' && path(target.pathname) === '/inbox'))
    )
  } catch {
    return false
  }
}

async function handleNotificationClick(notificationId, apiOrigin, browser, route) {
  try {
    const target = inboxTarget(apiOrigin, route)
    if (!target) return
    const existing = (await browser.listTabs(target.urlPattern)).find((tab) =>
      isInboxTab(tab, target.destination)
    )
    if (existing?.id !== undefined) {
      if (existing.url !== target.destination) {
        await browser.navigateTab(existing.id, target.destination)
      }
      await browser.activateTab(existing.id)
      if (existing.windowId !== undefined) await browser.focusWindow(existing.windowId)
      return
    }
    await browser.createTab(target.destination)
  } finally {
    await browser.clearNotification(notificationId)
  }
}

async function handleChromeNotificationClick(notificationId) {
  let settings
  try {
    const session = await chrome.storage.session.get(['sessionId', 'sessionApiOrigin'])
    if (!session.sessionId || !notificationId.startsWith(`ximail:${session.sessionId}:`)) {
      await chrome.notifications.clear(notificationId)
      return
    }
    settings = { apiOrigin: session.sessionApiOrigin }
  } catch {
    await chrome.notifications.clear(notificationId)
    return
  }
  await handleNotificationClick(notificationId, settings.apiOrigin, {
    listTabs: (urlPattern) => chrome.tabs.query({ url: urlPattern }),
    activateTab: async (tabId) => {
      await chrome.tabs.update(tabId, { active: true })
    },
    navigateTab: async (tabId, url) => {
      await chrome.tabs.update(tabId, { url })
    },
    focusWindow: async (windowId) => {
      await chrome.windows.update(windowId, { focused: true })
    },
    createTab: async (url) => {
      await chrome.tabs.create({ url })
    },
    clearNotification: async (id) => {
      await chrome.notifications.clear(id)
    },
  }).catch(() => {})
}

/**
 * 账号保险库：保存账号摘要与加密会话，恢复或移除已保存账号。
 * 通过 IndexedDB 保存加密材料；对面板仅暴露账号摘要。
 */
const DATABASE = 'ximail-accounts-v1'

// ── 1. IndexedDB 读写与加密密钥 ──
async function database() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE, 1)
    request.onupgradeneeded = () => {
      request.result.createObjectStore('vault')
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(new Error('无法打开账号存储。'))
  })
}

async function read(key) {
  const db = await database()
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction('vault', 'readonly')
      const request = tx.objectStore('vault').get(key)
      tx.oncomplete = () => resolve(request.result)
      tx.onerror = () => reject(new Error('无法读取账号存储。'))
    })
  } finally {
    db.close()
  }
}

async function write(key, value) {
  const db = await database()
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction('vault', 'readwrite')
      tx.objectStore('vault').put(value, key)
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(new Error('无法保存账号。'))
      tx.onabort = () => reject(new Error('账号保存已中止。'))
    })
  } finally {
    db.close()
  }
}

let keyPromise

function encryptionKey() {
  return (keyPromise ||= (async () => {
    const stored = await read('key')
    if (stored) return stored
    const key = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, [
      'encrypt',
      'decrypt',
    ])
    await write('key', key)
    return key
  })().catch((error) => {
    keyPromise = undefined
    throw error
  }))
}

const vault = async () => (await read('profiles')) || { active: null, profiles: [] }

// ── 2. 公开摘要与账号保存 ──
async function savedProfiles() {
  return (await vault()).profiles.map(({ id, apiOrigin, email, name }) => ({
    id,
    apiOrigin,
    email,
    name,
  }))
}

async function rememberProfile(auth) {
  const state = await vault()
  const previous = state.profiles.find(
    (p) => p.apiOrigin === auth.apiOrigin && p.email.toLowerCase() === auth.user.email.toLowerCase()
  )
  const id = previous?.id || crypto.randomUUID()
  const iv = crypto.getRandomValues(new Uint8Array(12))
  const data = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(id) },
    await encryptionKey(),
    new TextEncoder().encode(auth.token)
  )
  const profile = {
    id,
    apiOrigin: auth.apiOrigin,
    email: auth.user.email,
    name: auth.user.name,
    user: auth.user,
    secret: { iv: Array.from(iv), data: Array.from(new Uint8Array(data)) },
  }
  state.profiles = [...state.profiles.filter((p) => p.id !== id), profile]
  state.active = id
  await write('profiles', state)
  return id
}

// ── 3. 账号恢复、激活与移除 ──
async function restoreProfile(id) {
  const state = await vault()
  const profile = state.profiles.find((p) => p.id === (id ?? state.active))
  if (!profile) return null
  try {
    const bytes = await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: new Uint8Array(profile.secret.iv),
        additionalData: new TextEncoder().encode(profile.id),
      },
      await encryptionKey(),
      new Uint8Array(profile.secret.data)
    )
    return {
      id: crypto.randomUUID(),
      profileId: profile.id,
      token: new TextDecoder().decode(bytes),
      apiOrigin: profile.apiOrigin,
      user: profile.user,
    }
  } catch {
    throw new Error('无法解密此账号，请移除后重新添加。')
  }
}

async function activateProfile(id) {
  const state = await vault()
  if (id && !state.profiles.some((p) => p.id === id)) throw new Error('账号已移除。')
  state.active = id
  await write('profiles', state)
}

async function forgetProfile(id) {
  const state = await vault()
  state.profiles = state.profiles.filter((p) => p.id !== id)
  if (state.active === id) state.active = null
  await write('profiles', state)
}

/**
 * 邮件会话缓存：按账号和查询条件保存数据，刷新后维护已读状态。
 */
const prefix = CACHE_PREFIX
const pending = new Map()
const generations = new Map()
const pageGenerations = new Map()
const scope = (auth) => `${prefix}${auth.profileId || auth.id}:`
const keyFor = (auth, kind, params) => scope(auth) + kind + (params ? JSON.stringify(params) : '')

// ── 1. 查询缓存与并发请求复用 ──
async function cached(auth, kind, loader, force = false, params) {
  const key = keyFor(auth, kind, params)
  const generation = generations.get(scope(auth)) || 0
  const pageScope = `${scope(auth)}${params?.accountId}:${params?.allReceive}:${params?.type}`
  const pageGeneration = pageGenerations.get(pageScope) || 0
  const pendingKey = `${key}:${generation}:${pageGeneration}`
  const active = pending.get(pendingKey)
  if (active) {
    if (!force || active.force) return active.promise
    await active.promise.catch(() => {})
    return cached(auth, kind, loader, true, params)
  }
  const operation = (async () => {
    if (!force) {
      const entry = await updateSessionStore(
        async () => (await chrome.storage.session.get(key))[key]
      )
      if (entry) {
        touchCache(key)
        return entry.value
      }
    }
    const value = await loader()
    await updateSessionStore(async () => {
      if ((generations.get(scope(auth)) || 0) !== generation) return
      if (params?.emailId && (pageGenerations.get(pageScope) || 0) !== pageGeneration) return
      if (force && kind === 'messages' && !params?.emailId) {
        pageGenerations.set(pageScope, (pageGenerations.get(pageScope) || 0) + 1)
        const entries = Object.entries(await chrome.storage.session.get(null))
        const obsolete = entries
          .filter(
            ([k, entry]) =>
              k.startsWith(scope(auth)) &&
              entry.kind === 'messages' &&
              entry.params?.accountId === params?.accountId &&
              !!entry.params?.emailId
          )
          .map(([k]) => k)
        if (obsolete.length) await chrome.storage.session.remove(obsolete)
      }
      await storeCacheEntry(key, { kind, params, value })
    })
    return value
  })()
  pending.set(pendingKey, { promise: operation, force })
  try {
    return await operation
  } finally {
    pending.delete(pendingKey)
  }
}

// ── 2. 失效处理与后台刷新 ──
async function invalidateCache(auth) {
  await updateSessionStore(async () => {
    const start = scope(auth)
    generations.set(start, (generations.get(start) || 0) + 1)
    const keys = Object.keys(await chrome.storage.session.get(null)).filter((key) =>
      key.startsWith(start)
    )
    if (keys.length) await chrome.storage.session.remove(keys)
  })
}

async function refreshCachedMail(auth, client, isCurrent = async () => true) {
  if (!(await isCurrent())) return
  const entries = await updateSessionStore(async () =>
    Object.entries(await chrome.storage.session.get(null)).filter(([key]) =>
      key.startsWith(scope(auth))
    )
  )
  let accounts
  let failure
  if (entries.some(([, entry]) => entry.kind === 'accounts')) {
    try {
      accounts = await cached(auth, 'accounts', () => client.accountList(), true)
    } catch (error) {
      failure = error
    }
  }
  if (!(await isCurrent())) return
  const refresh = []
  const obsolete = []
  for (const [key, entry] of entries) {
    if (entry.kind !== 'messages' || !entry.params) continue
    const account = accounts?.find((item) => item.accountId === entry.params.accountId)
    if (accounts && (!account || (account.allReceive === 1 ? 1 : 0) !== entry.params.allReceive)) {
      obsolete.push(key)
      continue
    }
    if (!entry.params.emailId) refresh.push(entry.params)
  }
  // 限制预取工作量；其他邮箱在 data:changed 之后按需重新加载。
  const skipped = new Set(refresh.slice(6).map((params) => params.accountId))
  for (const [key, entry] of entries)
    if (entry.params && skipped.has(entry.params.accountId)) obsolete.push(key)
  if (obsolete.length)
    await updateSessionStore(async () => {
      // 使已删除或暂缓预取的邮箱分页请求失效，防止旧响应回写。
      generations.set(scope(auth), (generations.get(scope(auth)) || 0) + 1)
      await chrome.storage.session.remove(obsolete)
    })
  const selected = refresh.slice(0, 6)
  let index = 0
  await Promise.all(
    Array.from({ length: 3 }, async () => {
      while (index < selected.length) {
        if (!(await isCurrent())) return
        if (index >= selected.length) return
        const params = selected[index++]
        try {
          await cached(auth, 'messages', () => client.emailList(params), true, params)
        } catch (error) {
          if (!failure || (error instanceof ApiError && error.code === 401)) failure = error
        }
      }
    })
  )
  if (failure) throw failure
}

// ── 3. 已读状态同步 ──
async function markCachedRead(auth, ids) {
  await updateSessionStore(async () => {
    const entries = Object.entries(await chrome.storage.session.get(null)).filter(([key]) =>
      key.startsWith(scope(auth))
    )
    for (const [key, entry] of entries)
      if (entry.kind === 'messages') {
        const value = entry.value
        if (value.list.some((mail) => ids.includes(mail.emailId)))
          await storeCacheEntry(key, {
            ...entry,
            value: {
              ...value,
              list: value.list.map((mail) =>
                ids.includes(mail.emailId) ? { ...mail, unread: 1 } : mail
              ),
            },
          })
      }
  })
}

/**
 * 扩展后台入口：统一处理面板消息、账号切换、邮件缓存和通知轮询。
 * 会话相关操作通过队列及会话标识隔离，避免旧请求影响新账号。
 */
// ── 1. 后台状态与会话初始化 ──
const POLL_ALARM = 'ximail-poll'
const STATE_KEY = 'pollStateV2'
const DRAFT_KEY = 'composeDraft'

function record(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

let authIntent = 0
let controlQueue = Promise.resolve()
let alarmQueue = Promise.resolve()
let polling = null
let pollingSession = ''

function exclusive(action) {
  const result = controlQueue.then(action, action)
  controlQueue = result.catch(() => {})
  return result
}

const session = () => loadSessionAuth(chromeSessionStorage())
let ready

function ensureReady() {
  return (ready ||= exclusive(async () => {
    await compactSessionCache()
    const existing = await session()
    if (existing) {
      if (!existing.profileId) {
        existing.profileId = await rememberProfile(existing)
        await saveSessionAuth(chromeSessionStorage(), existing)
      }
      return
    }
    let restored
    try {
      restored = await restoreProfile()
    } catch {
      await activateProfile(null)
      return
    }
    if (!restored) return
    const poll = record(
      (await chrome.storage.local.get(`profilePoll:${restored.profileId}`))[
        `profilePoll:${restored.profileId}`
      ]
    )
    if ('watermark' in poll)
      await chrome.storage.local.set({ [STATE_KEY]: { ...poll, scope: restored.id } })
    await saveSessionAuth(chromeSessionStorage(), restored)
  }).catch((error) => {
    ready = undefined
    throw error
  }))
}

const dataChanged = (auth) =>
  chrome.runtime.sendMessage({ type: 'data:changed', sessionId: auth.id }).catch(() => {})

async function switchCurrent(auth) {
  const previous = await loadSessionAuth(chromeSessionStorage())
  if (previous?.profileId) {
    const draft = (await chrome.storage.session.get(DRAFT_KEY))[DRAFT_KEY]
    const state = (await chrome.storage.local.get(STATE_KEY))[STATE_KEY]
    await saveSessionData({ [`profileDraft:${previous.profileId}`]: draft || null })
    await chrome.storage.local.set({ [`profilePoll:${previous.profileId}`]: state || null })
  }
  await chrome.storage.session.remove([DRAFT_KEY, 'pollStatus'])
  await chrome.storage.local.remove(STATE_KEY)
  const draft = record(
    (await chrome.storage.session.get(`profileDraft:${auth.profileId}`))[
      `profileDraft:${auth.profileId}`
    ]
  )
  const poll = record(
    (await chrome.storage.local.get(`profilePoll:${auth.profileId}`))[
      `profilePoll:${auth.profileId}`
    ]
  )
  if ('value' in draft)
    await saveSessionData({
      [DRAFT_KEY]: { value: draft.value, version: draft.version, scope: auth.id },
    })
  if ('watermark' in poll)
    await chrome.storage.local.set({ [STATE_KEY]: { ...poll, scope: auth.id } })
  await saveSessionAuth(chromeSessionStorage(), auth)
  await activateProfile(auth.profileId)
  const settings = await loadSettings(chromeLocalStorage())
  await saveSettings(chromeLocalStorage(), { ...settings, apiOrigin: auth.apiOrigin })
}

const publicAuth = (auth) =>
  auth
    ? {
        id: auth.id,
        profileId: auth.profileId || auth.id,
        apiOrigin: auth.apiOrigin,
        user: { userId: auth.user.userId, email: auth.user.email, name: auth.user.name,
          account: auth.user.account, permKeys: auth.user.permKeys || [],
          type: auth.user.type, role: auth.user.role },
      }
    : null
const pollChanged = () => chrome.runtime.sendMessage({ type: 'poll:changed' }).catch(() => {})
const changed = () => chrome.runtime.sendMessage({ type: 'session:changed' }).catch(() => {})

// ── 2. 请求校验与错误边界 ──
function failure(error) {
  return {
    ok: false,
    error: error instanceof ApiError ? error.message : '操作未完成，请稍后重试。',
    code: error instanceof ApiError ? error.code : 500,
  }
}

function positive(value, label) {
  const n = Number(value)
  if (!Number.isSafeInteger(n) || n <= 0) throw new ApiError(`${label}无效，请刷新后重试。`, 400)
  return n
}

function cursor(value) {
  if (value === undefined) return 0
  const n = Number(value)
  if (!Number.isSafeInteger(n) || n < 0) throw new ApiError('邮件分页位置无效。', 400)
  return n
}

function text(value, label, max = 1000) {
  if (typeof value !== 'string' || value.length > max)
    throw new ApiError(`${label}格式不正确或过长。`, 400)
  return value
}

function plainTextHtml(value) {
  return `<div style="white-space:pre-wrap">${value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;')}</div>`
}

function trustedPanel(sender) {
  if (sender.id !== chrome.runtime.id || !sender.url) return false
  try {
    const url = new URL(sender.url)
    return (
      url.protocol === 'chrome-extension:' &&
      url.pathname === '/panel.html' &&
      [chrome.runtime.id, new URL(chrome.runtime.getURL('panel.html')).hostname].includes(
        url.hostname
      )
    )
  } catch {
    return false
  }
}

// ── 3. 会话清理与请求隔离 ──
async function clearCurrent(expectedId, forget = true) {
  const current = await session()
  if (expectedId && current?.id !== expectedId) return
  if (current) {
    if (current.profileId && !forget) {
      const draft = (await chrome.storage.session.get(DRAFT_KEY))[DRAFT_KEY]
      const poll = (await chrome.storage.local.get(STATE_KEY))[STATE_KEY]
      await saveSessionData({ [`profileDraft:${current.profileId}`]: draft || null })
      await chrome.storage.local.set({ [`profilePoll:${current.profileId}`]: poll || null })
    }
    if (current.profileId && forget) {
      await forgetProfile(current.profileId)
      await chrome.storage.session.remove([
        `profileDraft:${current.profileId}`,
        `mailSelection:${current.profileId}`,
      ])
      await chrome.storage.local.remove(`profilePoll:${current.profileId}`)
    }
    if (forget) await invalidateCache(current)
  }
  await activateProfile(null)
  await clearSessionAuth(chromeSessionStorage())
  await chrome.storage.session.remove([DRAFT_KEY, 'pollStatus'])
  await chrome.storage.local.remove([STATE_KEY, 'pollState'])
  await chrome.alarms.clear(POLL_ALARM)
  const notifications = await chrome.notifications.getAll().catch(() => ({}))
  await Promise.all(
    Object.keys(notifications)
      .filter((id) => id.startsWith('ximail:'))
      .map((id) => chrome.notifications.clear(id).catch(() => false))
  )
  await changed()
}

async function requireSession(message) {
  const auth = await session()
  if (!auth) throw new ApiError('登录已过期，请重新登录。', 401)
  if (message && message.sessionId !== auth.id)
    throw new ApiError('账号已切换，请等待面板刷新。', 409)
  return auth
}

async function withSession(message, action) {
  const auth = await requireSession(message)
  try {
    const result = await action(new XiMailClient(auth.apiOrigin, auth.token), auth)
    if ((await session())?.id !== auth.id) throw new ApiError('账号已切换，请重新操作。', 409)
    return result
  } catch (error) {
    if (error instanceof ApiError && error.code === 401)
      await exclusive(() => clearCurrent(auth.id))
    throw error
  }
}

// ── 4. 定时轮询与通知状态 ──
function ensurePollAlarm() {
  const action = async () => {
    const settings = await loadSettings(chromeLocalStorage())
    await chrome.alarms.clear(POLL_ALARM)
    if (settings.pollEnabled && (await session()))
      await chrome.alarms.create(POLL_ALARM, { periodInMinutes: settings.pollIntervalMinutes })
  }
  alarmQueue = alarmQueue.then(action, action)
  return alarmQueue
}

async function writePollStatus(id, status) {
  await exclusive(async () => {
    if ((await session())?.id === id) await saveSessionData({ pollStatus: status })
  })
}

async function performPoll(force) {
  const auth = await session()
  if (!auth) return
  const settings = await loadSettings(chromeLocalStorage())
  if (!settings.pollEnabled && !force) return
  const priorStatus = (await chrome.storage.session.get('pollStatus')).pollStatus
  if (!force && (priorStatus?.nextRetry || 0) > Date.now()) return
  try {
    await withSession(undefined, async (client, current) => {
      if (current.id !== auth.id) return
      const stored = record((await chrome.storage.local.get(STATE_KEY))[STATE_KEY])
      const state =
        stored.scope === current.id &&
        typeof stored.watermark === 'number' &&
        Number.isSafeInteger(stored.watermark) &&
        stored.watermark >= 0 &&
        typeof stored.initialized === 'boolean'
          ? { watermark: stored.watermark, initialized: stored.initialized }
          : { watermark: 0, initialized: false }
      let next = state
      const fresh = []
      if (!state.initialized) {
        next = nextPollState(state, await client.emailLatest({ emailId: 0, allReceive: 1 })).state
      } else {
        // 按编号递增分批读取，避免突发来信遗漏；下一次定时检查从末批继续。
        for (let batch = 0; batch < 4; batch++) {
          const result = await client.emailList({
            accountId: 0,
            allReceive: 1,
            emailId: next.watermark,
            timeSort: 1,
            full: 1,
            size: 50,
            type: 0,
          })
          const outcome = nextPollState(next, result.list)
          if (result.list.length && outcome.state.watermark <= next.watermark)
            throw new ApiError('通知分页未向前推进。', 502)
          next = outcome.state
          fresh.push(...outcome.fresh)
          if (result.list.length < 50) break
        }
      }
      if ((await session())?.id !== current.id) return
      if (!force && !(await loadSettings(chromeLocalStorage())).pollEnabled) return
      const outcome = buildNotification(fresh)
      const notificationId = `ximail:${current.id}:${next.watermark}`
      if (outcome.notified)
        await chrome.notifications.create(notificationId, {
          type: 'basic',
          iconUrl: chrome.runtime.getURL('icons/icon128.png'),
          title: outcome.title,
          message: outcome.message,
        })
      await exclusive(async () => {
        if ((await session())?.id !== current.id) {
          if (outcome.notified) await chrome.notifications.clear(notificationId)
          return
        }
        await chrome.storage.local.set({
          [STATE_KEY]: { ...next, scope: current.id },
          [`profilePoll:${current.profileId || current.id}`]: { ...next, scope: current.id },
        })
      })
      try {
        await refreshCachedMail(current, client, async () => (await session())?.id === current.id)
      } finally {
        if ((await session())?.id === current.id) await dataChanged(current)
      }
      await writePollStatus(current.id, { lastSuccess: new Date().toISOString() })
    })
  } catch (error) {
    const failures = (priorStatus?.failures || 0) + 1
    await writePollStatus(auth.id, {
      ...priorStatus,
      failures,
      lastError: failure(error).error,
      nextRetry:
        Date.now() +
        Math.max(
          settings.pollIntervalMinutes * 60000,
          Math.min(900000, 30000 * 2 ** Math.min(failures, 5))
        ),
    })
    throw error
  }
}

async function runPoll(force = false) {
  await ensureReady()
  const auth = await session()
  if (!auth) return
  if (polling) {
    if (pollingSession === auth.id) return polling
    await polling.catch(() => {})
    return runPoll(force)
  }
  pollingSession = auth.id
  polling = performPoll(force).finally(() => {
    polling = null
    void pollChanged()
  })
  void pollChanged()
  return polling
}

// ── 5. 面板消息分发 ──
async function handleOp(message, sender) {
  await ensureReady()
  switch (message.type) {
    case 'auth:status':
      return { ok: true, auth: publicAuth(await session()), profiles: await savedProfiles() }
    case 'auth:switch': {
      ++authIntent
      await exclusive(async () => {
        if (await session()) await requireSession(message)
        const auth = await restoreProfile(text(message.profileId, '账号标识', 100))
        if (!auth) throw new ApiError('账号已移除，请重新添加。', 404)
        await switchCurrent(auth)
      })
      await ensurePollAlarm()
      await changed()
      return { ok: true }
    }
    case 'auth:remove': {
      ++authIntent
      await exclusive(async () => {
        const current = await session()
        if (current) await requireSession(message)
        const id = text(message.profileId, '账号标识', 100)
        if (current?.profileId === id) await clearCurrent(current.id)
        else {
          await forgetProfile(id)
          await chrome.storage.session.remove([`profileDraft:${id}`, `mailSelection:${id}`])
          await chrome.storage.local.remove(`profilePoll:${id}`)
          if (current) await invalidateCache({ ...current, profileId: id })
        }
      })
      await changed()
      return { ok: true }
    }
    case 'auth:login': {
      const intent = ++authIntent
      const origin = normalizeOrigin(message.apiOrigin)
      if (!origin) throw new ApiError('站点地址仅支持 HTTPS 或本地 HTTP，不能包含登录信息。', 400)
      const token = await new XiMailClient(origin).login(
        text(message.email, '邮箱', 320).trim(),
        text(message.password, '密码', 4096)
      )
      const user = await new XiMailClient(origin, token).loginUserInfo()
      const auth = { id: crypto.randomUUID(), token, user, apiOrigin: origin }
      await exclusive(async () => {
        if (intent !== authIntent) throw new ApiError('登录操作已取消。', 409)
        auth.profileId = await rememberProfile(auth)
        await switchCurrent(auth)
      })
      await ensurePollAlarm()
      await changed()
      void runPoll().catch(() => {})
      if ((await session())?.id !== auth.id) throw new ApiError('登录状态已变化，请重新操作。', 409)
      return { ok: true, auth: publicAuth(auth) }
    }
    case 'auth:logout': {
      ++authIntent
      await exclusive(async () => {
        if (await session()) await requireSession(message)
        await clearCurrent()
      })
      return { ok: true }
    }
    case 'settings:get':
      return { ok: true, settings: await loadSettings(chromeLocalStorage()) }
    case 'settings:save': {
      const patch = record(message.settings)
      const keys = Object.keys(patch)
      const allowed = ['apiOrigin', 'theme', 'floatEnabled', 'pollEnabled', 'pollIntervalMinutes']
      if (
        !message.settings ||
        typeof message.settings !== 'object' ||
        Array.isArray(message.settings) ||
        keys.some((key) => !allowed.includes(key))
      )
        throw new ApiError('设置格式不正确。', 400)
      const expected = record(message.expected)
      const settings = await exclusive(async () => {
        if (await session()) await requireSession(message)
        const old = await loadSettings(chromeLocalStorage())
        if (keys.some((key) => key in expected && expected[key] !== old[key])) {
          throw new ApiError('同一项设置已在其他面板修改，请重新载入设置后再保存。', 409)
        }
        const input = { ...old, ...patch }
        const origin = input.apiOrigin ? normalizeOrigin(input.apiOrigin) : ''
        if (
          origin === null ||
          !['light', 'dark', 'system'].includes(input.theme) ||
          typeof input.floatEnabled !== 'boolean' ||
          typeof input.pollEnabled !== 'boolean' ||
          !Number.isFinite(input.pollIntervalMinutes) ||
          input.pollIntervalMinutes < 0.5 ||
          input.pollIntervalMinutes > 60
        ) {
          throw new ApiError('请检查站点、主题及轮询间隔（0.5—60 分钟）。', 400)
        }
        if (old.apiOrigin !== origin) ++authIntent
        const auth = await session()
        if (auth && auth.apiOrigin !== origin) await clearCurrent(auth.id, false)
        const merged = { ...input, apiOrigin: origin }
        await saveSettings(chromeLocalStorage(), merged)
        return merged
      })
      await ensurePollAlarm()
      return { ok: true, settings }
    }
    case 'api:accounts':
      return withSession(message, async (client, auth) => ({
        ok: true,
        accounts: await cached(
          auth,
          'accounts',
          () => client.accountList(),
          message.force === true
        ),
      }))
    case 'mail:selection':
      return withSession(message, async (_client, auth) => {
        const key = `mailSelection:${auth.profileId || auth.id}`
        if (message.accountId !== undefined)
          await saveSessionData({ [key]: positive(message.accountId, '邮箱编号') })
        return { ok: true, accountId: (await chrome.storage.session.get(key))[key] ?? null }
      })
    case 'api:account-delete':
      return withSession(message, async (client, auth) => {
        const id = positive(message.accountId, '邮箱编号')
        const accounts = await client.accountList()
        const account = accounts.find((item) => item.accountId === id)
        if (!account) throw new ApiError('邮箱不存在，请刷新列表。', 404)
        if (account.email?.toLowerCase() === auth.user.email.toLowerCase())
          throw new ApiError('登录主邮箱不能删除。', 400)
        await requireSession(message)
        await client.accountDelete(id)
        await invalidateCache(auth)
        await dataChanged(auth)
        return { ok: true }
      })
    case 'api:config':
      return withSession(message, async (client, auth) => {
        const config = await cached(
          auth,
          'config',
          () => client.websiteConfig(),
          message.force === true
        )
        if (!config || typeof config !== 'object') throw new ApiError('网站配置格式不兼容。', 502)
        const keys = [
          'title',
          'send',
          'r2Domain',
          'domainList',
          'manyEmail',
          'addEmail',
          'addEmailVerify',
          'addVerifyOpen',
          'minEmailPrefix',
        ]
        return { ok: true, config: Object.fromEntries(keys.map((key) => [key, config[key]])) }
      })
    case 'api:account-add':
      return withSession(message, async (client, auth) => {
        const email = text(message.email, '邮箱', 320).trim()
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
          throw new ApiError('请输入完整有效的邮箱地址。', 400)
        const config = await client.websiteConfig()
        if (config.addEmail !== 0 || config.manyEmail !== 0)
          throw new ApiError('站点未开放新增多邮箱。', 403)
        if (auth.user.type !== 0 && (
          config.addEmailVerify === 0 ||
          (config.addEmailVerify === 2 && config.addVerifyOpen === true)
        ))
          throw new ApiError('此站点要求网页人机验证，请在邮箱网站创建地址后刷新。', 403)
        const account = await client.accountAdd(email)
        await invalidateCache(auth)
        await dataChanged(auth)
        return { ok: true, account }
      })
    case 'api:messages':
      return withSession(message, async (client, auth) => {
        const params = {
          accountId: positive(message.accountId, '邮箱编号'),
          allReceive: message.allReceive === 1 ? 1 : 0,
          emailId: cursor(message.emailId),
          full: 1,
          size: Math.min(50, positive(message.size ?? 20, '每页数量')),
          timeSort: 0,
          type: message.folder === 'sent' ? 1 : 0,
        }
        return {
          ok: true,
          result: await cached(
            auth,
            'messages',
            () => client.emailList(params),
            message.force === true,
            params
          ),
        }
      })
    case 'api:content':
      return withSession(message, async (client, auth) => ({
        ok: true,
        content: await cached(auth, 'content', () => client.emailContent(positive(message.emailId, '邮件编号')),
          message.force === true, { emailId: positive(message.emailId, '邮件编号') }),
      }))
    case 'api:delete':
      return withSession(message, async (client, auth) => {
        if (!Array.isArray(message.emailIds) || !message.emailIds.length || message.emailIds.length > 50)
          throw new ApiError('邮件编号列表无效。', 400)
        await client.emailDelete(message.emailIds.map(id => positive(id, '邮件编号')))
        await invalidateCache(auth)
        await dataChanged(auth)
        return { ok: true }
      })
    case 'api:read':
      return withSession(message, async (client, auth) => {
        if (
          !Array.isArray(message.emailIds) ||
          !message.emailIds.length ||
          message.emailIds.length > 50
        )
          throw new ApiError('邮件编号列表无效。', 400)
        const ids = message.emailIds.map((id) => positive(id, '邮件编号'))
        await client.emailRead(ids)
        await markCachedRead(auth, ids)
        return { ok: true }
      })
    case 'api:send':
      return withSession(message, async (client, auth) => {
        const accountId = positive(message.accountId, '发件邮箱')
        const accounts = await client.accountList()
        const sender = accounts.find(account => account.accountId === accountId)
        if (!sender) throw new ApiError('发件邮箱不存在，请刷新后重试。', 400)
        if (
          !Array.isArray(message.receiveEmail) ||
          !message.receiveEmail.length ||
          message.receiveEmail.length > 50
        )
          throw new ApiError('请填写 1—50 个收件地址。', 400)
        const receiveEmail = message.receiveEmail.map((v) => text(v, '收件人', 320).trim())
        if (receiveEmail.some((v) => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)))
          throw new ApiError('收件地址格式不正确。', 400)
        const body = text(message.text ?? message.content, '正文', 100000)
        const subject = text(message.subject, '主题', 500).trim()
        if (!subject || !body.trim()) throw new ApiError('请填写主题和正文。', 400)
        const reply = message.sendType === 'reply'
        const email = await client.emailSend({
          accountId,
          name: sender.name || '',
          receiveEmail,
          subject,
          text: body,
          content: plainTextHtml(body),
          sendType: reply ? 'reply' : 'send',
          emailId: reply ? positive(message.emailId, '原邮件编号') : undefined,
        })
        await invalidateCache(auth)
        await dataChanged(auth)
        return { ok: true, email }
      })
    case 'api:fill-data':
      return withSession(message, async (client) => {
        const accountId = positive(message.accountId, '邮箱编号')
        const account = (await client.accountList()).find((a) => a.accountId === accountId)
        if (!account) throw new ApiError('所选邮箱不存在，请刷新。', 404)
        const latest = await client.emailLatest({
          accountId,
          allReceive: message.allReceive === 1 ? 1 : 0,
          emailId: 0,
        })
        const candidate = latest
          .map((mail) => ({ mail, code: extractVerificationCode(mail.code, mail.text) }))
          .find((item) => item.code)
        return {
          ok: true,
          address: account.email,
          verificationCode: candidate?.code || '',
          createTime: candidate?.mail.createTime,
          subject: candidate?.mail.subject,
          sourceAddress: candidate?.mail.toEmail || account.email,
        }
      })
    case 'page:fill': {
      await requireSession(message)
      if (message.kind !== 'email' && message.kind !== 'verification-code')
        throw new ApiError('填充类型无效。', 400)
      const value = text(message.value, '填充内容', 320)
      if (!value) throw new ApiError('没有可填充的内容。', 400)
      // A floating panel belongs to its host tab; a standalone extension tab
      // should fill the active ordinary webpage, just like the toolbar popup.
      const hostTabId = sender.tab?.url?.startsWith(chrome.runtime.getURL('')) ? undefined : sender.tab?.id
      const tabId =
        hostTabId ??
        (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0]?.id
      if (tabId === undefined) throw new ApiError('没有找到可填充的网页。', 400)
      try {
        const response = await chrome.tabs.sendMessage(
          tabId,
          { type: 'fill:apply', kind: message.kind, value },
          { frameId: 0 }
        )
        if (!response?.ok) throw new ApiError(response?.error || '页面填充失败。', 400)
        return { ok: true }
      } catch (error) {
        if (error instanceof ApiError) throw error
        throw new ApiError(
          '当前页面无法填充；浏览器内部页不支持，安装前已打开的普通网页请刷新。',
          400
        )
      }
    }
    case 'draft:get':
      return withSession(message, async (_client, auth) => {
        const stored = record((await chrome.storage.session.get(DRAFT_KEY))[DRAFT_KEY])
        return {
          ok: true,
          draft: stored.scope === auth.id ? stored.value : null,
          draftVersion:
            stored.scope === auth.id && typeof stored.version === 'number' ? stored.version : 0,
        }
      })
    case 'draft:save':
      return exclusive(async () => {
        const auth = await requireSession(message)
        const stored = record((await chrome.storage.session.get(DRAFT_KEY))[DRAFT_KEY])
        const currentVersion =
          stored.scope === auth.id && typeof stored.version === 'number' ? stored.version : 0
        const expectedVersion = cursor(message.expectedVersion)
        const writerId = text(message.writerId, '草稿窗口标识', 100)
        const writeSeq = positive(message.writeSeq, '草稿写入顺序')
        const sameWriter = stored.scope === auth.id && stored.writerId === writerId
        if (
          (sameWriter && typeof stored.writeSeq === 'number' && writeSeq <= stored.writeSeq) ||
          (expectedVersion !== currentVersion && !sameWriter)
        )
          throw new ApiError(
            '草稿已在其他面板更新，本页内容尚未保存。请先复制需要保留的内容，再重新载入草稿。',
            409
          )
        if (
          message.draft !== null &&
          (!message.draft ||
            typeof message.draft !== 'object' ||
            JSON.stringify(message.draft).length > 500000)
        )
          throw new ApiError('临时草稿过大或格式不正确（总计最多 500KB 文本）。', 400)
        const version = currentVersion + 1
        await saveSessionData({
          [DRAFT_KEY]: { scope: auth.id, value: message.draft, version, writerId, writeSeq },
        })
        return { ok: true, draftVersion: version }
      })
    case 'poll:status':
      return {
        ok: true,
        status: {
          ...record((await chrome.storage.session.get('pollStatus')).pollStatus),
          running: polling !== null,
        },
      }
    case 'poll:run':
      await requireSession(message)
      await runPoll(true)
      await requireSession(message)
      return { ok: true }
    default:
      throw new ApiError('不支持的操作。', 400)
  }
}

chrome.runtime.onMessage.addListener((input, sender, respond) => {
  if (
    !input ||
    typeof input !== 'object' ||
    !('type' in input) ||
    typeof input.type !== 'string' ||
    ['session:changed', 'data:changed', 'poll:changed'].includes(input.type)
  )
    return false
  if (!trustedPanel(sender)) {
    respond({ ok: false, error: '拒绝未授权的扩展消息。', code: 403 })
    return false
  }
  handleOp(input, sender)
    .then(respond)
    .catch((error) => respond(failure(error)))
  return true
})
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === POLL_ALARM) void runPoll().catch(() => {})
})
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.pollEnabled || changes.pollIntervalMinutes))
    void ensurePollAlarm().catch(() => {})
})
chrome.notifications.onClicked.addListener((id) => {
  if (id.startsWith('ximail:')) void handleChromeNotificationClick(id).catch(() => {})
})

// ── 6. 扩展启动与事件监听 ──
async function initializeAccounts() {
  await ensureReady()
  await ensurePollAlarm()
}

chrome.runtime.onInstalled.addListener(() => {
  void initializeAccounts().catch(() => {})
})
chrome.runtime.onStartup.addListener(() => {
  void initializeAccounts().catch(() => {})
})
