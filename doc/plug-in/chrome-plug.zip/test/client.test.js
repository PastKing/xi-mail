import test from 'node:test'
import assert from 'node:assert/strict'
import { XiMailClient, ApiError, normalizeOrigin, extractVerificationCode, attachmentUrl } from '../assets/settings-storage.js'

function client(handler) {
  return new XiMailClient('https://mail.example.com', 'fixture-token', async (url, init) => {
    const data = await handler(new URL(url), init)
    return new Response(JSON.stringify({ code: 200, data }), { headers: { 'Content-Type': 'application/json' } })
  })
}
test('Xi-Mail uses /api, the raw JWT and the language header', async () => {
  await client((url, init) => {
    assert.equal(url.pathname, '/api/login')
    assert.equal(init.headers.Authorization, 'fixture-token')
    assert.equal(init.headers['accept-language'], 'zh')
    assert.deepEqual(JSON.parse(init.body), { email: 'user@example.com', password: 'fixture-password' })
    return { token: 'new-token' }
  }).login('user@example.com', 'fixture-password')
})
test('login user info retains primary mailbox, permissions and administrator identity', async () => {
  const user = { userId: 1, email: 'user@example.com', account: { accountId: 1 }, permKeys: ['*'], role: {}, type: 0 }
  const result = await client(() => user).loginUserInfo()
  assert.deepEqual(result.permKeys, ['*'])
  assert.equal(result.type, 0)
  assert.equal(result.account.accountId, 1)
})
test('mailbox pagination follows sort and ID cursors, preserves canSend', async () => {
  const requests = []
  const accounts = Array.from({ length: 31 }, (_, n) => ({ accountId: n + 1, sort: n < 30 ? 2 : 0, email: `box${n}@example.com`, canSend: n === 0 }))
  const result = await client(url => {
    requests.push(url)
    return url.searchParams.get('accountId') === '0' ? accounts.slice(0, 30) : accounts.slice(30)
  }).accountList()
  assert.equal(result.length, 31)
  assert.equal(result[0].canSend, true)
  assert.equal(requests[1].searchParams.get('accountId'), '30')
  assert.equal(requests[1].searchParams.get('lastSort'), '2')
})
test('repeating mailbox pages fail instead of looping or duplicating addresses', async () => {
  const rows = Array.from({ length: 30 }, (_, n) => ({ accountId: n + 1, sort: 0, email: `box${n}@example.com` }))
  await assert.rejects(client(() => rows).accountList(), /分页重复/)
})
test('full message content is retrieved separately from the truncated list', async () => {
  const c = client(url => {
    if (url.pathname === '/api/email/list') return { list: [{ emailId: 7, accountId: 1, text: '摘要' }], total: 1 }
    assert.equal(url.pathname, '/api/email/content')
    assert.equal(url.searchParams.get('emailId'), '7')
    return { emailId: 7, content: '<p>完整正文</p>', text: '完整正文' }
  })
  assert.equal((await c.emailList({ accountId: 1 })).list[0].text, '摘要')
  assert.equal((await c.emailContent(7)).text, '完整正文')
})
test('sent folder, read state and comma-separated delete IDs match backend contract', async () => {
  const calls = []
  const c = client((url, init) => {
    calls.push({ url, init })
    return url.pathname.endsWith('/list') ? { list: [], total: 0 } : null
  })
  await c.emailList({ accountId: 1, type: 1 })
  await c.emailRead([7, 8])
  await c.emailDelete([7, 8])
  assert.equal(calls[0].url.searchParams.get('type'), '1')
  assert.deepEqual(JSON.parse(calls[1].init.body), { emailIds: [7, 8] })
  assert.equal(calls[2].url.searchParams.get('emailIds'), '7,8')
})
test('HTTP 200 business errors and expired JWT are surfaced', async () => {
  const c = new XiMailClient('https://mail.example.com', 'expired', async () => new Response(JSON.stringify({ code: 401, message: 'expired' })))
  await assert.rejects(c.websiteConfig(), error => error instanceof ApiError && error.code === 401)
})
test('HTML errors from access restrictions are actionable', async () => {
  const c = new XiMailClient('https://mail.example.com', '', async () => new Response('<html>blocked</html>', { status: 403 }))
  await assert.rejects(c.websiteConfig(), /JSON.*403/)
})
test('server URLs reject credentials and non-local insecure HTTP', () => {
  assert.equal(normalizeOrigin('https://name:secret@example.com'), null)
  assert.equal(normalizeOrigin('http://example.com'), null)
  assert.equal(normalizeOrigin('http://127.0.0.1:3000/api'), 'http://127.0.0.1:3000')
})
test('verification codes require context; supplied Xi-Mail AI codes are supported', () => {
  assert.equal(extractVerificationCode('A12345', ''), 'A12345')
  assert.equal(extractVerificationCode('', '您的验证码：123456'), '123456')
  assert.equal(extractVerificationCode('', 'Your verification code is 345678'), '345678')
  assert.equal(extractVerificationCode('', '订单号 123456'), '')
})
test('attachment URLs preserve keys and refuse executable schemes', () => {
  assert.equal(attachmentUrl('https://files.example.com', { key: 'attachments/a b.pdf' }), 'https://files.example.com/attachments/a%20b.pdf')
  assert.equal(attachmentUrl('https://files.example.com', { key: 'javascript:alert(1)' }), '')
  assert.equal(attachmentUrl('https://files.example.com', { key: '../secret' }), '')
})
