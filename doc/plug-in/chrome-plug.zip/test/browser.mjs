// Real Chromium extension test. The HTTP server is a local Xi-Mail API fixture.
// No production account, production address, or external email is used.
import assert from 'node:assert/strict'
import { chromium } from 'playwright'
import { createServer } from 'node:http'
import { mkdtemp, mkdir, readdir, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, resolve, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const extension = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const artifacts = join(extension, 'test-artifacts')
async function waitUntil(predicate) {
  for (let i = 0; i < 150; i++) {
    if (await predicate()) return
    await new Promise(resolve => setTimeout(resolve, 50))
  }
  throw new Error('Timed out waiting for browser state')
}
await mkdir(artifacts, { recursive: true })
const calls = []
const fullText = '完整正文只通过详情接口返回。'.repeat(40) + '正文结尾标记 END-OF-MESSAGE'
const accounts = [
  { accountId: 1, email: 'reader@example.com', name: '收信地址', sort: 0, allReceive: 0, canSend: false },
  { accountId: 2, email: 'writer@example.com', name: '发信地址', sort: 0, allReceive: 0, canSend: true },
]
let messages = Array.from({ length: 24 }, (_, n) => ({ emailId: 100 - n, accountId: 1,
  name: n === 0 ? 'Xi-Mail 测试来信' : `发件人 ${n}`, sendEmail: 'sender@example.com', toEmail: 'reader@example.com',
  subject: n === 0 ? '欢迎来到你的随身邮箱' : `测试邮件 ${n}`, text: n === 0 ? '验证码：123456（列表摘要）' : '邮件摘要',
  code: n === 0 ? '123456' : '', unread: 0, type: 0, createTime: '2026-11-03 04:00:00', attList: [] }))
const sent = []
const user = { userId: 1, name: '测试用户', email: accounts[0].email, type: 0, permKeys: ['*'], account: accounts[0], role: {} }
const config = { send: 0, r2Domain: '', manyEmail: 0, addEmail: 0, addEmailVerify: 1, minEmailPrefix: 3, domainList: ['@example.com', '@mail.example.net'] }
const server = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost')
  let raw = ''
  for await (const chunk of req) raw += chunk
  const body = raw ? JSON.parse(raw) : null
  calls.push({ method: req.method, path: url.pathname, query: Object.fromEntries(url.searchParams), body, auth: req.headers.authorization })
  const ok = data => { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ code: 200, data })) }
  if (url.pathname === '/form') {
    res.setHeader('Content-Type', 'text/html; charset=utf-8')
    return res.end('<!doctype html><html><head><title>Local fill fixture</title></head><body><label>邮箱 <input type="email" id="email"></label><label>验证码 <input autocomplete="one-time-code" id="code"></label></body></html>')
  }
  if (url.pathname === '/api/login') return ok({ token: body.email.startsWith('other') ? 'other-token' : 'fixture-token' })
  if (url.pathname === '/api/my/loginUserInfo') return ok(req.headers.authorization === 'other-token'
    ? { ...user, email: 'other@example.com', name: '另一个账号', type: 1, permKeys: ['account:query'], userId: 2 }
    : user)
  if (url.pathname === '/api/setting/websiteConfig') return ok(config)
  if (url.pathname === '/api/account/list') return ok(accounts)
  if (url.pathname === '/api/account/add') { const a = { accountId: 3, email: body.email, name: '新邮箱', sort: 0, allReceive: 0, canSend: false }; accounts.push(a); return ok(a) }
  if (url.pathname === '/api/email/latest') return ok(messages.slice(0, 20))
  if (url.pathname === '/api/email/list') {
    const pool = url.searchParams.get('type') === '1' ? sent : messages
    const cursor = Number(url.searchParams.get('emailId'))
    return ok({ list: pool.filter(m => !cursor || m.emailId < cursor).slice(0, 20), total: pool.length })
  }
  if (url.pathname === '/api/email/content') return ok({ emailId: Number(url.searchParams.get('emailId')), text: fullText,
    content: `<h2>完整正文</h2><p>${fullText}</p><script>parent.__unsafe = true</script><img src="https://tracker.invalid/pixel">` })
  if (url.pathname === '/api/email/read') return ok(null)
  if (url.pathname === '/api/email/send') {
    sent.push({ emailId: 200, accountId: body.accountId, subject: body.subject, toEmail: body.receiveEmail[0], text: body.text, type: 1, createTime: '2026-11-03 04:00:00' })
    return ok([sent.at(-1)])
  }
  if (url.pathname === '/api/email/delete') { const ids = url.searchParams.get('emailIds').split(',').map(Number); messages = messages.filter(m => !ids.includes(m.emailId)); return ok(null) }
  res.statusCode = 404; ok(null)
})
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
const origin = `http://127.0.0.1:${server.address().port}`
const profile = await mkdtemp(join(tmpdir(), 'ximail-extension-test-'))
let context
try {
  let executablePath = process.env.CHROME_PATH
  if (!executablePath && process.platform === 'win32') {
    const cache = join(process.env.LOCALAPPDATA, 'ms-playwright')
    const versions = (await readdir(cache)).filter(n => /^chromium-\d+$/.test(n)).sort((a, b) => Number(b.split('-')[1]) - Number(a.split('-')[1]))
    if (versions.length) executablePath = join(cache, versions[0], 'chrome-win64', 'chrome.exe')
  }
  context = await chromium.launchPersistentContext(profile, {
    executablePath, headless: true, viewport: { width: 480, height: 640 },
    ignoreDefaultArgs: ['--hide-scrollbars'],
    args: [`--disable-extensions-except=${extension}`, `--load-extension=${extension}`],
  })
  const worker = context.serviceWorkers()[0] || await context.waitForEvent('serviceworker')
  const extensionId = new URL(worker.url()).host
  const errors = []
  worker.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()) })
  const page = await context.newPage()
  page.on('pageerror', error => errors.push(error.message))
  await page.goto(`chrome-extension://${extensionId}/panel.html`)
  await page.getByRole('button', { name: '连接邮箱', exact: true }).waitFor()
  assert.equal(await page.getByRole('textbox', { name: '邮箱站点', exact: true }).inputValue(), '')
  assert.equal(await page.locator('body').innerText().then(text => /你的随身邮箱|随手即达|为你的 Xi-Mail 而来/.test(text)), false)
  await page.screenshot({ path: join(artifacts, 'login.png') })
  await page.evaluate(() => chrome.storage.local.set({ pollEnabled: false }))
  await page.getByRole('textbox', { name: '邮箱站点', exact: true }).fill(origin)
  await page.getByRole('textbox', { name: '登录邮箱', exact: true }).fill('reader@example.com')
  await page.getByLabel('密码', { exact: true }).fill('fixture-password')
  await page.getByRole('button', { name: '连接邮箱', exact: true }).click()
  await page.getByRole('button', { name: /Xi-Mail 测试来信/ }).waitFor()
  assert.equal(await page.getByRole('button', { name: '填入邮箱', exact: true }).count(), 0)
  assert.equal(await page.getByRole('button', { name: '获取验证码', exact: true }).count(), 0)
  const mailbox = page.getByRole('combobox', { name: '选择邮箱', exact: true })
  await mailbox.click()
  await page.getByRole('option', { name: 'writer@example.com', exact: true }).waitFor()
  await page.screenshot({ path: join(artifacts, 'mailbox-dropdown.png') })
  await page.keyboard.press('ArrowDown')
  await page.keyboard.press('Enter')
  await waitUntil(async () => (await mailbox.textContent()).includes('writer@example.com'))
  await page.getByRole('button', { name: /Xi-Mail 测试来信/ }).waitFor()
  assert.ok(calls.some(call => call.path === '/api/email/list' && call.query.accountId === '2'))
  await mailbox.click()
  await page.getByRole('option', { name: 'reader@example.com', exact: true }).click()
  await page.getByRole('button', { name: /Xi-Mail 测试来信/ }).waitFor()
  const search = page.getByRole('searchbox', { name: '搜索已加载的邮件', exact: true })
  await search.click()
  assert.equal(await search.evaluate(node => getComputedStyle(node).outlineStyle), 'none')
  await search.fill('测试邮件 1')
  assert.equal(await page.locator('.mail-row').count(), 11)
  await search.fill('')
  await page.screenshot({ path: join(artifacts, 'inbox.png') })
  assert.equal(await page.locator('.mail-row').count(), 20)
  await page.getByRole('button', { name: '加载更多邮件', exact: true }).click()
  await waitUntil(async () => await page.locator('.mail-row').count() === 24)
  await page.getByRole('button', { name: /Xi-Mail 测试来信/ }).click()
  await page.frameLocator('iframe[title="邮件正文"]').getByText(/END-OF-MESSAGE/).waitFor()
  assert.equal(await page.frameLocator('iframe[title="邮件正文"]').locator('script, img').count(), 0)
  assert.equal(await page.evaluate(() => window.__unsafe), undefined)
  await page.screenshot({ path: join(artifacts, 'reader.png') })
  await page.getByRole('button', { name: '返回列表', exact: true }).click()
  // Exercise actual content script and the service worker fill message path.
  const target = await context.newPage()
  await target.setViewportSize({ width: 1000, height: 900 })
  target.on('pageerror', error => { errors.push(error.message); console.error('Content script:', error.message) })
  await target.goto(`${origin}/form`)
  await target.locator('#email').focus()
  const auth = await page.evaluate(async () => (await chrome.runtime.sendMessage({ type: 'auth:status' })).auth)
  const filled = await page.evaluate(async ({ id, tabId }) => {
    // sender.tab is absent in popup messages, so focus the target's Chrome tab.
    await chrome.tabs.update(tabId, { active: true })
    return chrome.runtime.sendMessage({ type: 'page:fill', sessionId: id, kind: 'email', value: 'reader@example.com' })
  }, { id: auth.id, tabId: await page.evaluate(async origin => (await chrome.tabs.query({})).find(t => t.url === `${origin}/form`).id, origin) })
  assert.equal(filled.ok, true, JSON.stringify(filled))
  assert.equal(await target.locator('#email').inputValue(), 'reader@example.com')
  await target.locator('#code').focus()
  const codeFilled = await page.evaluate(id => chrome.runtime.sendMessage({ type: 'page:fill', sessionId: id, kind: 'verification-code', value: '123456' }), auth.id)
  assert.equal(codeFilled.ok, true, JSON.stringify(codeFilled))
  assert.equal(await target.locator('#code').inputValue(), '123456')
  // Open the real draggable launcher inside its closed Shadow DOM by position.
  const viewport = target.viewportSize()
  await target.mouse.click(viewport.width - 20, viewport.height - 52)
  await waitUntil(() => target.frames().some(f => f.url().includes('panel.html#float')))
  const floating = target.frames().find(f => f.url().includes('panel.html#float'))
  await floating.getByRole('heading', { name: '收件箱', exact: true }).waitFor()
  const floatingElement = await floating.frameElement()
  const launcherState = () => floatingElement.evaluate(node => {
    const launcher = node.getRootNode().querySelector('.ximail-float-btn')
    return { hidden: launcher.hidden, display: getComputedStyle(launcher).display,
      left: launcher.style.left, top: launcher.style.top }
  })
  const hiddenLauncher = await launcherState()
  assert.equal(hiddenLauncher.hidden, true, 'Expanded window hides the launcher')
  assert.equal(hiddenLauncher.display, 'none', 'Launcher cannot be clicked or dragged while expanded')
  assert.equal(parseFloat(hiddenLauncher.left), viewport.width - 40, 'Launcher defaults to the browser right edge')
  const beforeDrag = await floatingElement.boundingBox()
  const grip = { x: beforeDrag.x + 130, y: beforeDrag.y - 20 }
  await target.mouse.move(grip.x, grip.y)
  await target.mouse.down()
  await target.mouse.move(grip.x - 130, grip.y - 60, { steps: 12 })
  await target.mouse.up()
  const afterDrag = await floatingElement.boundingBox()
  assert.ok(Math.abs(afterDrag.x - beforeDrag.x + 130) < 2, 'Dragging the open titlebar moves the window horizontally')
  assert.ok(Math.abs(afterDrag.y - beforeDrag.y + 60) < 2, 'Dragging the open titlebar moves the window vertically')
  const savedPosition = await page.evaluate(async () => (await chrome.storage.local.get('floatPanelPosition')).floatPanelPosition)
  assert.ok(savedPosition && Number.isFinite(savedPosition.left), 'Window position is persisted')
  assert.deepEqual(await launcherState(), hiddenLauncher, 'Dragging the window does not move its hidden launcher')
  await target.screenshot({ path: join(artifacts, 'floating-window.png') })
  const floatingFill = await floating.evaluate(async () => {
    const { auth } = await chrome.runtime.sendMessage({ type: 'auth:status' })
    return chrome.runtime.sendMessage({ type: 'page:fill', sessionId: auth.id, kind: 'email', value: 'floating@example.com' })
  })
  assert.equal(floatingFill.ok, true, JSON.stringify(floatingFill))
  assert.equal(await target.locator('#email').inputValue(), 'floating@example.com')
  await floating.evaluate(() => window.parent.postMessage({ type: 'ximail:close' }, '*'))
  await waitUntil(async () => !(await launcherState()).hidden)
  assert.equal((await launcherState()).display, 'flex', 'Closing restores the draggable launcher')
  const collapsed = await launcherState()
  assert.equal(collapsed.left, hiddenLauncher.left, 'Closing returns the icon to its original right-side dock')
  assert.equal(collapsed.top, hiddenLauncher.top, 'Dragging the window does not change the icon height')
  await target.mouse.click(parseFloat(collapsed.left) + 20, parseFloat(collapsed.top) + 20)
  const afterReopen = await floatingElement.boundingBox()
  assert.ok(Math.abs(afterReopen.x - afterDrag.x) < 2 && Math.abs(afterReopen.y - afterDrag.y) < 2,
    'Closing and reopening retains the dragged window position')
  await floating.evaluate(() => window.parent.postMessage({ type: 'ximail:close' }, '*'))
  await waitUntil(async () => !(await launcherState()).hidden)
  const iconCenter = { x: parseFloat(collapsed.left) + 20, y: parseFloat(collapsed.top) + 20 }
  await target.mouse.move(iconCenter.x, iconCenter.y)
  await target.mouse.down()
  await target.mouse.move(iconCenter.x - 180, iconCenter.y - 700, { steps: 8 })
  assert.ok(parseFloat((await launcherState()).left) < viewport.width - 100, 'Icon follows horizontal movement during dragging')
  await target.mouse.up()
  const snapped = await launcherState()
  assert.equal(parseFloat(snapped.left), viewport.width - 40, 'Releasing the icon snaps it back to the right edge')
  assert.equal(parseFloat(snapped.top), parseFloat(collapsed.top) - 700, 'Snapping preserves the new vertical position')
  const persistedDock = await page.evaluate(async () => (await chrome.storage.local.get('floatPosition')).floatPosition)
  assert.equal(persistedDock.left, viewport.width - 40)
  assert.equal(persistedDock.top, parseFloat(snapped.top))
  await target.mouse.click(viewport.width - 20, parseFloat(snapped.top) + 20)
  const afterIconDrag = await floatingElement.boundingBox()
  assert.ok(Math.abs(afterIconDrag.x - (viewport.width - 480 - 8 + 1)) < 2,
    'After moving the icon, the window opens beside the right-side dock')
  const newWindowPosition = await floatingElement.evaluate(node => node.parentElement.getBoundingClientRect().top)
  assert.ok(Math.abs(newWindowPosition - parseFloat(snapped.top)) < 2, 'The new icon height determines the next window position')
  assert.equal((await launcherState()).display, 'none', 'Reopening after moving the icon hides it again')
  await floating.evaluate(() => window.parent.postMessage({ type: 'ximail:close' }, '*'))
  await waitUntil(async () => !(await launcherState()).hidden)
  assert.equal((await launcherState()).top, snapped.top, 'Closing restores the newly chosen dock height')
  // A classic scrollbar occupies viewport space and must not cover the icon.
  const scrollbarStyle = await target.addStyleTag({ content: 'html { overflow-y: scroll; scrollbar-gutter: stable; } body { min-height: 1800px; } ::-webkit-scrollbar { width: 18px; }' })
  const clientWidth = await target.evaluate(() => document.documentElement.clientWidth)
  assert.ok(clientWidth < viewport.width, 'Fixture reserves a visible scrollbar gutter')
  await waitUntil(async () => parseFloat((await launcherState()).left) === clientWidth - 40)
  assert.equal((await launcherState()).top, snapped.top, 'Scrollbar appearance preserves the dock height')
  await target.mouse.click(clientWidth - 20, parseFloat(snapped.top) + 20)
  const withScrollbar = await floatingElement.boundingBox()
  assert.ok(withScrollbar.x + withScrollbar.width <= clientWidth, 'Expanded panel also stays to the left of the scrollbar')
  await floating.evaluate(() => window.parent.postMessage({ type: 'ximail:close' }, '*'))
  await waitUntil(async () => !(await launcherState()).hidden)
  await target.screenshot({ path: join(artifacts, 'docked-with-scrollbar.png') })
  await scrollbarStyle.evaluate(node => node.remove())
  await waitUntil(async () => parseFloat((await launcherState()).left) === viewport.width - 40)
  await page.bringToFront()
  await page.getByRole('button', { name: '写信', exact: true }).click()
  await page.getByRole('textbox', { name: '主题', exact: true }).waitFor()
  await page.getByRole('combobox', { name: '选择邮箱', exact: true }).click()
  assert.equal(await page.getByRole('option').count(), 1)
  assert.equal(await page.getByRole('option').textContent(), 'writer@example.com')
  await page.keyboard.press('Escape')
  await page.getByRole('textbox', { name: '收件人', exact: true }).fill('recipient@example.com')
  await page.getByRole('textbox', { name: '主题', exact: true }).fill('插件发送测试')
  await page.getByRole('textbox', { name: '正文', exact: true }).fill('安全文本 <b>不是 HTML</b>')
  await page.getByRole('button', { name: '收件箱', exact: true }).click()
  await page.getByRole('button', { name: '写信', exact: true }).click()
  await waitUntil(async () => await page.locator('textarea').inputValue() === '安全文本 <b>不是 HTML</b>')
  await page.screenshot({ path: join(artifacts, 'compose.png') })
  await page.getByRole('button', { name: '发送邮件', exact: true }).click()
  await page.getByRole('heading', { name: '已发送', exact: true }).waitFor()
  const sendCall = calls.find(c => c.path === '/api/email/send')
  assert.equal(sendCall.body.accountId, 2)
  assert.equal(sendCall.body.name, '发信地址')
  assert.equal(sendCall.body.content.includes('&lt;b&gt;'), true)
  assert.ok(calls.some(c => c.path === '/api/email/list' && c.query.type === '1'))
  await page.getByRole('button', { name: '偏好设置', exact: true }).click()
  await page.getByRole('combobox', { name: '外观', exact: true }).selectOption('dark')
  await page.getByRole('button', { name: '保存偏好', exact: true }).click()
  await page.locator('html[data-theme="dark"]').waitFor()
  await page.screenshot({ path: join(artifacts, 'settings-dark.png') })
  await page.getByRole('button', { name: '收件箱', exact: true }).click()
  await page.getByRole('button', { name: /Xi-Mail 测试来信/ }).waitFor()
  await page.getByRole('combobox', { name: '选择邮箱', exact: true }).click()
  await page.screenshot({ path: join(artifacts, 'mailbox-dropdown-dark.png') })
  await page.keyboard.press('Escape')
  await page.getByRole('button', { name: /Xi-Mail 测试来信/ }).click()
  await page.getByRole('button', { name: '删除邮件', exact: true }).click()
  await page.getByRole('button', { name: '确认', exact: true }).click()
  await page.locator('.reader').waitFor({ state: 'detached' })
  assert.ok(calls.some(c => c.path === '/api/email/delete' && c.query.emailIds === '100'))
  await page.getByRole('button', { name: '邮箱管理', exact: true }).click()
  assert.equal(await page.getByText(/可用后缀：/).count(), 0)
  await page.getByRole('textbox', { name: '邮箱前缀', exact: true }).fill('new')
  await page.getByRole('combobox', { name: '邮箱后缀', exact: true }).click()
  await page.getByRole('option', { name: '@mail.example.net', exact: true }).click()
  await page.screenshot({ path: join(artifacts, 'account-create.png') })
  await page.getByRole('button', { name: '创建邮箱', exact: true }).click()
  await page.getByText('new@mail.example.net', { exact: true }).waitFor()
  assert.ok(calls.some(call => call.path === '/api/account/add' && call.body.email === 'new@mail.example.net'))
  await page.getByRole('button', { name: '切换账号', exact: true }).click()
  await page.getByRole('button', { name: '连接另一个账号', exact: true }).click()
  await page.getByRole('textbox', { name: '登录邮箱', exact: true }).fill('other@example.com')
  await page.getByLabel('密码', { exact: true }).fill('fixture-password')
  await page.getByRole('button', { name: '连接邮箱', exact: true }).click()
  await page.getByRole('heading', { name: '收件箱', exact: true }).waitFor()
  assert.equal(await page.getByRole('button', { name: '写信', exact: true }).isDisabled(), true)
  await page.getByRole('button', { name: '切换账号', exact: true }).click()
  await page.locator('.profile-card').first().getByRole('button', { name: '切换', exact: true }).click()
  await page.getByRole('heading', { name: '收件箱', exact: true }).waitFor()
  assert.equal(await page.getByRole('button', { name: '写信', exact: true }).isDisabled(), false)
  const stale = await page.evaluate(id => chrome.runtime.sendMessage({ type: 'api:messages', sessionId: id, accountId: 1 }), auth.id)
  assert.equal(stale.code, 409)
  await page.goto(`chrome-extension://${extensionId}/panel.html#float`)
  await page.setViewportSize({ width: 320, height: 600 })
  await page.getByRole('heading', { name: '收件箱', exact: true }).waitFor()
  await page.screenshot({ path: join(artifacts, 'floating-narrow.png') })
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false,
    JSON.stringify(await page.evaluate(() => ({ width: innerWidth, html: document.documentElement.scrollWidth, body: document.body.scrollWidth,
      overflow: [...document.querySelectorAll('*')].filter(n => n.getBoundingClientRect().right > innerWidth).map(n => [n.tagName, n.className, n.getBoundingClientRect().right]) }))))
  assert.equal(errors.length, 0, errors.join('\n'))
  console.log('PASS: real MV3 service worker, login, pagination, full content/sandbox, fill, draft restore, send, sent folder, delete, create mailbox, theme, multiple accounts, session isolation, narrow layout')
  console.log(`Screenshots: ${artifacts}`)
} finally {
  await context?.close()
  await new Promise(resolve => server.close(resolve))
  await rm(profile, { recursive: true, force: true })
}
