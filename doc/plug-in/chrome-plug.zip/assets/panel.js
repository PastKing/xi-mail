import { safeEmailDocument, attachmentUrl, extractVerificationCode } from './settings-storage.js'

// Xi-Mail's panel deliberately has no bundled server address or credentials.
const root = document.querySelector('#root')
const state = {
  auth: null, profiles: [], settings: {}, config: {}, accounts: [], accountId: null,
  view: 'inbox', messages: [], total: 0, more: false, detail: null,
  loading: false, error: '', query: '', generation: 0, addingLogin: false,
  draft: null, draftVersion: 0, draftSeq: 0, draftQueue: Promise.resolve(),
}
const writerId = crypto.randomUUID()
const media = matchMedia('(prefers-color-scheme: dark)')
function syncPanelMode() { document.documentElement.classList.toggle('float-panel', location.hash === '#float') }
syncPanelMode()
window.addEventListener('hashchange', syncPanelMode)

const paths = {
  mail: '<rect x="3" y="5" width="18" height="14" rx="4"/><path d="m4 7 8 6 8-6"/>',
  inbox: '<path d="M4 4h16l2 12v4H2v-4L4 4Z"/><path d="M2 14h6l2 3h4l2-3h6"/>',
  send: '<path d="m22 2-7 20-4-9L2 9 22 2Z"/><path d="m22 2-11 11"/>',
  write: '<path d="m15 5 4 4M4 20l5-1L21 7a3 3 0 0 0-4-4L5 15l-1 5Z"/>',
  accounts: '<rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/><path d="M7 6.5h.01M7 17.5h.01M12 6.5h5M12 17.5h5"/>',
  settings: '<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3"/><circle cx="15" cy="17" r="3"/>',
  refresh: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6 6a8 8 0 0 1 14 6M18 18A8 8 0 0 1 4 12"/>',
  back: '<path d="m14 6-6 6 6 6"/>',
  copy: '<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',
  fill: '<path d="M4 4h7M4 4v7M20 20h-7M20 20v-7M4 4l6 6M20 20l-6-6"/>',
  trash: '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  logout: '<path d="M9 4H4v16h5M10 12h12m-5-5 5 5-5 5"/>',
}
function icon(name) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  svg.setAttribute('viewBox', '0 0 24 24')
  svg.setAttribute('fill', 'none')
  svg.setAttribute('stroke', 'currentColor')
  svg.setAttribute('stroke-width', '1.7')
  svg.setAttribute('stroke-linecap', 'round')
  svg.setAttribute('stroke-linejoin', 'round')
  svg.setAttribute('aria-hidden', 'true')
  svg.innerHTML = paths[name] || paths.mail // Only static, local icon paths enter this sink.
  return svg
}
function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag)
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null) continue
    if (key.startsWith('on')) node.addEventListener(key.slice(2).toLowerCase(), value)
    else if (key === 'class') node.className = value
    else if (key in node && !key.startsWith('aria-')) node[key] = value
    else node.setAttribute(key, value)
  }
  for (const child of children.flat(Infinity)) {
    if (child !== null && child !== undefined && child !== false)
      node.append(child instanceof Node ? child : document.createTextNode(String(child)))
  }
  return node
}
function button(label, name, action, className = 'button', disabled = false) {
  return el('button', { type: 'button', class: className, title: label, 'aria-label': label,
    disabled, onClick: () => run(action) }, name && icon(name), el('span', {}, label))
}
function field(label, input) { return el('label', { class: 'field' }, el('span', {}, label), input) }
function input(type, value, attrs = {}) { return el('input', { type, value: value || '', ...attrs }) }
function can(permission) {
  return state.auth?.user.type === 0 || state.auth?.user.permKeys?.some(p => p === '*' || p === permission)
}
function currentAccount() { return state.accounts.find(a => a.accountId === state.accountId) }
function senderAccounts() {
  const sendable = state.accounts.filter(a => a.canSend === true)
  return sendable.length ? sendable : state.accounts
}
function theme() {
  document.documentElement.dataset.theme = state.settings.theme === 'system'
    ? (media.matches ? 'dark' : 'light') : (state.settings.theme || 'light')
}
media.addEventListener('change', theme)
let toastTimer
function toast(message, error = false) {
  document.querySelector('.toast')?.remove()
  const node = el('div', { class: `toast ${error ? 'error' : ''}`, role: error ? 'alert' : 'status' },
    icon(error ? 'close' : 'check'), el('span', {}, message),
    button('关闭提示', 'close', () => node.remove(), 'icon-button'))
  document.body.append(node)
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => node.remove(), error ? 8000 : 3500)
}
async function run(action) {
  try { return await action() } catch (error) { toast(error.message || '操作失败，请重试。', true) }
}
async function request(type, data = {}) {
  const sessionId = state.auth?.id || null
  const result = await chrome.runtime.sendMessage({ type, sessionId, ...data })
  if (!result?.ok) {
    if (result?.code === 401) void bootstrap()
    throw new Error(result?.error || '无法连接扩展后台，请重新打开插件。')
  }
  if (sessionId && sessionId !== state.auth?.id && !type.startsWith('auth:'))
    throw new Error('账号已切换，请重新操作。')
  return result
}
function empty(title, description, name = 'inbox') {
  return el('div', { class: 'empty' }, el('div', { class: 'empty-icon' }, icon(name)),
    el('h3', {}, title), el('p', {}, description))
}
function openWebsite(path = '/inbox') {
  if (state.auth) return chrome.tabs.create({ url: new URL(path, state.auth.apiOrigin).href })
}

function render() {
  theme()
  if (!state.auth || state.addingLogin) return renderLogin()
  const rail = el('nav', { class: 'rail', 'aria-label': '主导航' },
    button('写信', 'write', () => navigate('compose'), `nav-compose ${state.view === 'compose' ? 'active' : ''}`, !can('email:send') || state.config.send !== 0),
    ...[['inbox', '收件箱', 'inbox'], ['sent', '已发送', 'send'], ['accounts', '邮箱管理', 'accounts']]
      .map(([view, label, name]) => button(label, name, () => navigate(view), `nav-item ${state.view === view ? 'active' : ''}`)),
    el('div', { class: 'rail-spacer' }),
    button('偏好设置', 'settings', () => navigate('settings'), `nav-item ${state.view === 'settings' ? 'active' : ''}`),
    button('切换账号', null, () => navigate('profiles'), `avatar ${state.view === 'profiles' ? 'active' : ''}`))
  rail.lastChild.querySelector('span').textContent = (state.auth.user.name || state.auth.user.email).slice(0, 1).toUpperCase()
  const titles = { inbox: '收件箱', sent: '已发送', accounts: '邮箱管理', compose: '写一封信', settings: '偏好设置', profiles: '账号空间' }
  const header = el('header', { class: 'topbar' },
    el('h1', {}, state.detail ? '阅读邮件' : titles[state.view]),
    el('div', { class: 'header-actions' },
      button('打开网页版', 'arrow', () => openWebsite(), 'icon-button'),
      ['inbox', 'sent', 'accounts'].includes(state.view) && button('刷新', 'refresh', () => loadWorkspace(true), 'icon-button', state.loading)))
  const body = el('main', { class: 'workspace' }, header)
  if (state.loading && !state.accounts.length) body.append(empty('正在同步邮箱', '稍等片刻，邮件即将到达。', 'refresh'))
  else if (state.detail) body.append(renderDetail())
  else if (state.view === 'inbox' || state.view === 'sent') body.append(renderMailbox())
  else if (state.view === 'compose') body.append(renderCompose())
  else if (state.view === 'accounts') body.append(renderAccounts())
  else if (state.view === 'settings') body.append(renderSettings())
  else body.append(renderProfiles())
  root.replaceChildren(el('div', { class: 'app' }, rail, body))
}
function renderLogin() {
  const origin = input('url', state.settings.apiOrigin, { placeholder: 'https://mail.example.com', required: true, autoComplete: 'url' })
  const email = input('email', '', { placeholder: '你的登录邮箱', required: true, autoComplete: 'username' })
  const password = input('password', '', { placeholder: '输入密码', required: true, autoComplete: 'current-password' })
  const submit = el('button', { class: 'button primary login-submit', type: 'submit' }, '连接邮箱', icon('arrow'))
  const form = el('form', { class: 'login-form', onSubmit: event => {
    event.preventDefault()
    void run(async () => {
      submit.disabled = true
      submit.firstChild.textContent = '正在连接…'
      try {
        await request('auth:login', { apiOrigin: origin.value.trim(), email: email.value.trim(), password: password.value })
        state.addingLogin = false
        await bootstrap()
      } finally { password.value = ''; submit.disabled = false; submit.firstChild.textContent = '连接邮箱' }
    })
  } }, field('邮箱站点', origin), field('登录邮箱', email), field('密码', password), submit)
  const content = el('div', { class: 'login-page' },
    el('div', { class: 'login-intro' },
      state.auth && button('返回', 'back', () => { state.addingLogin = false; render() }, 'button ghost'),
      el('h1', {}, state.addingLogin ? '添加账号' : '连接邮箱'),
      el('p', {}, '填写邮箱站点和账号信息。')),
    form, el('footer', { class: 'login-footer' }, '密码仅用于登录，不会保存在本机。'))
  root.replaceChildren(content)
}
async function navigate(view) {
  if (state.view === 'compose') await state.draftQueue
  ++state.generation
  state.loading = false
  state.view = view; state.detail = null; state.error = ''; state.query = ''
  render()
  if (view === 'inbox' || view === 'sent') await loadMessages()
  if (view === 'compose') {
    const scope = state.auth?.id
    const result = await request('draft:get')
    if (state.view !== view || state.auth?.id !== scope) return
    state.draft = result.draft; state.draftVersion = result.draftVersion
    render()
  }
}
function dropdown(label, value, options, onChange) {
  const id = `select-${crypto.randomUUID()}`
  const selected = options.find(option => option.value === value)
  const text = el('span', { class: 'select-value' }, selected?.label || '暂无可选项')
  const trigger = el('button', { type: 'button', class: 'select-trigger', role: 'combobox',
    'aria-label': label, 'aria-haspopup': 'listbox', 'aria-expanded': 'false', 'aria-controls': id,
    title: selected?.label || '', disabled: !options.length }, text, icon('back'))
  const menu = el('div', { id, popover: 'auto', role: 'listbox', 'aria-label': label, class: 'select-menu' })
  const wrapper = el('div', { class: 'custom-select' }, trigger, menu)
  const items = options.map(option => el('button', { type: 'button', role: 'option', class: 'select-option',
    tabIndex: -1, 'aria-selected': String(option.value === value), title: option.label,
    onClick: () => {
      menu.hidePopover()
      text.textContent = option.label; trigger.title = option.label
      items.forEach(item => item.setAttribute('aria-selected', String(item.title === option.label)))
      trigger.focus({ preventScroll: true })
      void run(() => onChange(option.value))
    } }, el('span', {}, option.label), icon('check')))
  menu.append(...items)
  function open(last = false) {
    menu.showPopover()
    const rect = trigger.getBoundingClientRect()
    const width = Math.min(Math.max(rect.width, 220), innerWidth - 24)
    const below = innerHeight - rect.bottom - 12
    const above = rect.top - 12
    const upwards = below < 160 && above > below
    const height = Math.min(240, upwards ? above : below)
    Object.assign(menu.style, { width: `${width}px`, left: `${Math.max(12, Math.min(rect.left, innerWidth - width - 12))}px`,
      top: upwards ? 'auto' : `${rect.bottom + 5}px`, bottom: upwards ? `${innerHeight - rect.top + 5}px` : 'auto', maxHeight: `${Math.max(40, height)}px` })
    const chosen = last ? items.at(-1) : items.find(item => item.getAttribute('aria-selected') === 'true') || items[0]
    chosen?.focus({ preventScroll: true })
    chosen?.scrollIntoView({ block: 'nearest' })
  }
  let openOnPointerDown = false
  trigger.addEventListener('pointerdown', () => { openOnPointerDown = menu.matches(':popover-open') })
  trigger.addEventListener('click', () => {
    const close = openOnPointerDown || menu.matches(':popover-open')
    openOnPointerDown = false
    if (close) menu.hidePopover()
    else open()
  })
  trigger.addEventListener('keydown', event => {
    if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      event.preventDefault(); open(event.key === 'End' || event.key === 'ArrowUp')
    }
  })
  menu.addEventListener('keydown', event => {
    if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      event.preventDefault()
      const index = items.indexOf(document.activeElement)
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 :
        (index + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length
      items[next]?.focus()
    }
    if (event.key === 'Escape' || event.key === 'Tab') {
      menu.hidePopover()
      trigger.focus({ preventScroll: true })
    }
  })
  menu.addEventListener('toggle', event => trigger.setAttribute('aria-expanded', String(event.newState === 'open')))
  return wrapper
}
function accountSelect(value = state.accountId, accounts = state.accounts, onChange) {
  return dropdown('选择邮箱', value, accounts.map(account => ({ value: account.accountId, label: account.email })), onChange)
}
function renderMailbox() {
  const account = currentAccount()
  const picker = el('section', { class: 'mailbox-picker' }, el('div', { class: 'mailbox-symbol' }, icon('mail')),
    el('div', { class: 'picker-content' }, el('small', {}, '当前邮箱'), accountSelect(state.accountId, state.accounts, async id => {
      state.accountId = id; state.messages = []; state.query = ''
      await request('mail:selection', { accountId: id }); await loadMessages()
    })), button('复制邮箱', 'copy', () => copy(account?.email), 'icon-button', !account))
  const section = el('div', { class: 'mail-page' }, picker)
  const search = input('search', state.query, { placeholder: '搜索已加载的邮件', 'aria-label': '搜索已加载的邮件', onInput: event => {
    state.query = event.target.value; updateMailList()
  } })
  section.append(el('div', { class: 'mail-tools' }, el('div', { class: 'search-box' }, icon('search'), search),
    el('span', { class: 'count' }, `${state.total} 封`)))
  const list = el('div', { class: 'mail-list', 'aria-live': 'polite' })
  section.append(list)
  queueMicrotask(updateMailList)
  return section
}
function updateMailList() {
  const list = root.querySelector('.mail-list')
  if (!list) return
  const q = state.query.trim().toLowerCase()
  const rows = state.messages.filter(m => [m.subject, m.name, m.sendEmail, m.text, m.toEmail].some(v => String(v || '').toLowerCase().includes(q)))
  list.replaceChildren()
  if (state.error) list.append(el('div', { class: 'inline-error', role: 'alert' }, state.error,
    button('重试', 'refresh', () => loadMessages(true), 'button secondary')))
  else if (!rows.length) list.append(empty(state.loading ? '正在加载邮件' : q ? '没有匹配的邮件' : '这里暂时很安静',
    state.loading ? '正在与邮箱同步…' : q ? '试试其他关键词，或加载更多邮件。' : '新邮件到来后，会出现在这里。'))
  for (const mail of rows) {
    const unread = mail.unread === 0 && state.view !== 'sent'
    const sender = state.view === 'sent' ? mail.toEmail : mail.name || mail.sendEmail
    list.append(el('button', { type: 'button', class: `mail-row ${unread ? 'unread' : ''}`, onClick: () => run(() => openMail(mail)) },
      el('span', { class: 'sender-avatar' }, (sender || '?').slice(0, 1).toUpperCase()),
      el('span', { class: 'mail-summary' }, el('span', { class: 'mail-meta' }, el('strong', {}, sender || '未知发件人'), el('time', {}, formatDate(mail.createTime, true))),
        el('span', { class: 'mail-subject' }, unread && el('i', { class: 'unread-dot' }), mail.subject || '（无主题）'),
        el('span', { class: 'mail-bottom' },
          el('span', { class: 'mail-preview' }, mail.text || (mail.content ? 'HTML 邮件 · 点击阅读全文' : '点击查看邮件')),
          mail.code && el('span', { class: 'code-badge' }, mail.code)))))
  }
  if (state.more) list.append(button(state.loading ? '正在加载…' : '加载更多邮件', 'arrow', () => loadMessages(false, true), 'button load-more', state.loading))
}
async function loadWorkspace(force = false) {
  const generation = ++state.generation
  state.loading = true; state.error = ''; render()
  try {
    const [accounts, config, selection] = await Promise.all([
      request('api:accounts', { force }), request('api:config', { force }), request('mail:selection'),
    ])
    if (generation !== state.generation) return
    state.accounts = accounts.accounts; state.config = config.config
    if (!state.accounts.some(a => a.accountId === state.accountId))
      state.accountId = state.accounts.find(a => a.accountId === selection.accountId)?.accountId || state.accounts[0]?.accountId || null
  } catch (error) { if (generation === state.generation) { state.error = error.message; toast(error.message, true) } }
  finally { if (generation === state.generation) { state.loading = false; render() } }
  if (generation === state.generation && ['inbox', 'sent'].includes(state.view)) await loadMessages(force)
}
async function loadMessages(force = false, append = false) {
  const generation = ++state.generation
  state.loading = true; state.error = ''
  if (!append) { state.messages = []; state.total = 0; state.more = false }
  render()
  if (!state.accountId) { state.loading = false; render(); return }
  try {
    const { result } = await request('api:messages', { accountId: state.accountId, folder: state.view,
      emailId: append ? state.messages.at(-1)?.emailId || 0 : 0, size: 20, force })
    if (generation !== state.generation) return
    const seen = new Set(append ? state.messages.map(m => m.emailId) : [])
    state.messages = [...(append ? state.messages : []), ...result.list.filter(m => !seen.has(m.emailId))]
    state.total = result.total; state.more = result.list.length === 20 && state.messages.length < state.total
  } catch (error) { if (generation === state.generation) state.error = error.message }
  finally { if (generation === state.generation) { state.loading = false; render() } }
}
async function openMail(mail) {
  const generation = ++state.generation
  state.detail = { ...mail, pending: true }; render()
  try {
    const { content } = await request('api:content', { emailId: mail.emailId })
    if (generation !== state.generation) return
    state.detail = { ...mail, ...content, pending: false }; render()
    if (mail.unread === 0 && state.view !== 'sent') {
      await request('api:read', { emailIds: [mail.emailId] }); mail.unread = 1
    }
  } catch (error) {
    if (generation === state.generation && state.detail) { state.detail.pending = false; state.detail.error = error.message; render() }
  }
}
function renderDetail() {
  const mail = state.detail
  const content = el('div', { class: 'reader' }, el('div', { class: 'reader-toolbar' },
    button('返回列表', 'back', () => { ++state.generation; state.detail = null; render() }, 'button ghost'),
    el('div', { class: 'row' }, button('回复', 'write', async () => {
      const prior = await request('draft:get')
      if (prior.draft && !await confirmAction('替换现有草稿？', '回复会替换当前账号尚未发送的草稿。')) return
      state.draft = { accountId: mail.accountId, receiveEmail: mail.sendEmail, subject: /^re:/i.test(mail.subject || '') ? mail.subject : `Re: ${mail.subject || ''}`, text: '', sendType: 'reply', emailId: mail.emailId }
      state.draftVersion = prior.draftVersion
      state.detail = null; state.view = 'compose'; await saveDraft(); render()
    }, 'icon-button', !can('email:send') || state.config.send !== 0 || state.view === 'sent'),
      button('删除邮件', 'trash', async () => {
        if (!await confirmAction('删除这封邮件？', '邮件将从当前邮箱移除。')) return
        await request('api:delete', { emailIds: [mail.emailId] }); state.detail = null; await loadMessages(true)
      }, 'icon-button danger', !can('email:delete')))),
    el('div', { class: 'reader-heading' }, el('h2', {}, mail.subject || '（无主题）'),
      el('p', {}, mail.name || mail.sendEmail), el('small', {}, `${mail.sendEmail || ''} → ${mail.toEmail || ''}`),
      el('time', {}, formatDate(mail.createTime))))
  if (mail.pending) content.append(empty('正在加载完整正文', '正在读取邮件内容。', 'refresh'))
  else if (mail.error) content.append(el('div', { class: 'inline-error', role: 'alert' }, mail.error,
    button('重新加载正文', 'refresh', () => openMail(mail), 'button secondary')))
  else {
    const code = extractVerificationCode(mail.code, mail.text)
    if (code) content.append(button(`复制验证码 ${code}`, 'copy', () => copy(code), 'button code-copy'))
    const frame = el('iframe', { class: 'email-document', title: '邮件正文', sandbox: 'allow-popups allow-popups-to-escape-sandbox', referrerPolicy: 'no-referrer' })
    frame.srcdoc = safeEmailDocument(mail.content || '', mail.text || '')
    content.append(frame)
    for (const attachment of mail.attList || []) {
      const url = attachmentUrl(state.config.r2Domain || state.auth.apiOrigin, attachment)
      if (url) content.append(el('a', { class: 'attachment', href: url, target: '_blank', rel: 'noopener noreferrer' },
        icon('arrow'), attachment.name || attachment.filename || '附件'))
    }
  }
  return content
}

function saveDraft(value = state.draft) {
  const scope = state.auth?.id
  const snapshot = value ? { ...value } : null
  const seq = ++state.draftSeq
  const next = state.draftQueue.then(async () => {
    if (scope !== state.auth?.id) return
    const result = await request('draft:save', { draft: snapshot, expectedVersion: state.draftVersion, writerId, writeSeq: seq })
    state.draftVersion = result.draftVersion
  })
  state.draftQueue = next.catch(error => { toast(error.message, true) })
  return next
}
function renderCompose() {
  const options = senderAccounts()
  const draft = state.draft ||= { accountId: options.find(a => a.accountId === state.accountId)?.accountId || options[0]?.accountId,
    receiveEmail: '', subject: '', text: '', sendType: 'send' }
  if (!options.some(a => a.accountId === draft.accountId)) draft.accountId = options[0]?.accountId
  if (!can('email:send') || state.config.send !== 0 || !options.length)
    return empty('当前无法发信', '站点未开启发信，或当前账号没有发信权限。', 'send')
  const change = (key, value) => { draft[key] = value; void saveDraft().catch(() => {}) }
  const submit = el('button', { type: 'submit', class: 'button primary' }, icon('send'), '发送邮件')
  const form = el('form', { class: 'compose-page', onSubmit: event => {
    event.preventDefault()
    void run(async () => {
      if (submit.disabled) return
      submit.disabled = true
      const fields = [...form.querySelectorAll('input, textarea, select, .select-trigger')]
      fields.forEach(field => { field.disabled = true })
      let sent = false
      try {
        await state.draftQueue
        await request('api:send', { ...draft, receiveEmail: String(draft.receiveEmail).split(/[,;，；\n]+/).map(v => v.trim()).filter(Boolean) })
        sent = true
        state.draft = null
        await saveDraft(null)
        toast('邮件已提交发送'); await navigate('sent')
      } catch (error) {
        if (sent) { toast('邮件已提交发送，但本地草稿清理失败，请勿重复发送。', true); await navigate('sent') }
        else throw error
      } finally { submit.disabled = false; fields.forEach(field => { field.disabled = false }) }
    })
  } },
    !state.accounts.some(a => a.canSend) && el('p', { class: 'hint' }, '当前没有可对外发信的邮箱，仅可尝试发送站内邮件。'),
    field('发件人', accountSelect(draft.accountId, options, id => change('accountId', id))),
    field('收件人', input('text', draft.receiveEmail, { required: true, placeholder: '多个地址用逗号分隔', onInput: e => change('receiveEmail', e.target.value) })),
    field('主题', input('text', draft.subject, { required: true, maxLength: 500, placeholder: '给这封信一个标题', onInput: e => change('subject', e.target.value) })),
    field('正文', el('textarea', { value: draft.text || '', required: true, maxLength: 100000, placeholder: '写下你想说的话…', onInput: e => change('text', e.target.value) })),
    el('div', { class: 'compose-footer' }, el('small', {}, draft.sendType === 'reply' ? '正在回复邮件 · 草稿暂存于浏览器会话' : '草稿暂存于浏览器会话'), submit))
  return form
}
function renderAccounts() {
  const section = el('div', { class: 'scroll-page' }, el('div', { class: 'section-intro' },
    el('p', {}, `${state.accounts.length} 个邮箱地址`)))
  for (const account of state.accounts) section.append(el('div', { class: 'account-card' },
    el('div', { class: 'sender-avatar' }, icon('mail')), el('div', { class: 'account-info' },
      el('strong', {}, account.name || '邮箱'), el('small', {}, account.email),
      el('span', { class: 'tag' }, account.canSend ? '支持对外发信' : '收信 / 站内通信')),
    el('div', { class: 'row' }, button('复制邮箱', 'copy', () => copy(account.email), 'icon-button'),
      button('删除邮箱', 'trash', async () => {
        if (!await confirmAction('删除这个邮箱？', `删除 ${account.email} 后将无法继续使用这个地址。`)) return
        await request('api:account-delete', { accountId: account.accountId }); await loadWorkspace(true); toast('邮箱已删除')
      }, 'icon-button danger', !can('account:delete') || account.email.toLowerCase() === state.auth.user.email.toLowerCase()))))
  const config = state.config
  const allowed = can('account:add') && config.addEmail === 0 && config.manyEmail === 0
  if (allowed) {
    const domains = [...new Set((config.domainList || []).filter(domain => typeof domain === 'string' && domain.trim())
      .map(domain => '@' + domain.trim().replace(/^@+/, '')))]
    let domain = domains[0] || ''
    const prefix = input('text', '', { placeholder: '邮箱前缀', 'aria-label': '邮箱前缀', required: true,
      minLength: Number(config.minEmailPrefix) || 1, maxLength: 64, pattern: '[^\\s@]+', autoCapitalize: 'none', spellcheck: false })
    const suffix = dropdown('邮箱后缀', domain, domains.map(value => ({ value, label: value })), value => { domain = value })
    const add = el('button', { type: 'submit', class: 'button primary', disabled: !domains.length }, icon('plus'), '创建邮箱')
    section.append(el('form', { class: 'create-account', onSubmit: e => {
      e.preventDefault(); void run(async () => {
        add.disabled = true
        try {
          if (!domain) throw new Error('站点暂未配置可用邮箱后缀。')
          await request('api:account-add', { email: prefix.value.trim() + domain }); await loadWorkspace(true); toast('邮箱已创建')
        }
        finally { add.disabled = false }
      })
    } }, el('h3', {}, '添加新地址'),
      el('div', { class: 'field' }, el('span', {}, '新邮箱'), el('div', { class: 'address-input' }, prefix, suffix)),
      add, el('small', { class: 'muted' }, domains.length ? '如站点要求人机验证，请在网页版完成创建。' : '站点暂未配置可用邮箱后缀。')))
  } else section.append(el('p', { class: 'hint' }, '当前站点或角色未开放创建新邮箱。'))
  return section
}
function renderSettings() {
  const baseline = { ...state.settings }
  const draft = { ...baseline }
  const select = el('select', { 'aria-label': '外观', onChange: e => { draft.theme = e.target.value } },
    ...[['system', '跟随系统'], ['light', '浅色'], ['dark', '深色']].map(([value, text]) => el('option', { value, selected: draft.theme === value }, text)))
  function toggle(key, title, description) {
    return el('label', { class: 'setting-row' }, el('span', {}, el('strong', {}, title), el('small', {}, description)),
      input('checkbox', '', { checked: draft[key], role: 'switch', onChange: e => { draft[key] = e.target.checked } }))
  }
  const submit = el('button', { type: 'submit', class: 'button primary' }, icon('check'), '保存偏好')
  return el('form', { class: 'scroll-page settings-page', onSubmit: event => {
    event.preventDefault(); void run(async () => {
      submit.disabled = true
      try {
        const keys = ['theme', 'floatEnabled', 'pollEnabled', 'pollIntervalMinutes']
        const dirty = keys.filter(k => draft[k] !== baseline[k])
        const result = await request('settings:save', {
          settings: Object.fromEntries(dirty.map(k => [k, draft[k]])),
          expected: Object.fromEntries(dirty.map(k => [k, baseline[k]])),
        })
        state.settings = result.settings; theme(); toast('偏好已保存'); render()
      } finally { submit.disabled = false }
    })
  } },
    el('section', { class: 'settings-card' }, el('h3', {}, '外观与交互'), field('外观', select),
      toggle('floatEnabled', '网页悬浮入口', '在普通网页上快速打开邮箱')),
    el('section', { class: 'settings-card' }, el('h3', {}, '收信提醒'),
      toggle('pollEnabled', '新邮件通知', '浏览器运行期间定时检查新邮件'),
      field('检查间隔（分钟）', input('number', draft.pollIntervalMinutes, { min: 0.5, max: 60, step: 0.5, required: true,
        onInput: e => { draft.pollIntervalMinutes = Number(e.target.value) } }))),
    submit, el('div', { class: 'about' }, el('small', {}, '版本 1.0.0')))
}
function renderProfiles() {
  return el('div', { class: 'scroll-page' }, el('div', { class: 'section-intro' },
    el('p', {}, '切换或管理已连接的账号。')),
    ...state.profiles.map(profile => el('div', { class: 'profile-card' },
      el('div', { class: 'account-info' }, el('strong', {}, profile.name || profile.email || '邮箱账号'),
        el('small', {}, profile.user?.email || profile.email || ''),
        profile.id === state.auth.profileId && el('span', { class: 'tag' }, '当前使用')),
      button('切换', 'arrow', async () => { await request('auth:switch', { profileId: profile.id }); await bootstrap() }, 'icon-button', profile.id === state.auth.profileId),
      button('移除账号', 'trash', async () => {
        if (!await confirmAction('移除这个账号？', '只移除插件中的登录信息，不会删除站点账号或邮件。')) return
        await request('auth:remove', { profileId: profile.id }); await bootstrap()
      }, 'icon-button danger'))),
    button('连接另一个账号', 'plus', () => { state.addingLogin = true; render() }, 'button secondary full-width'),
    button('退出当前账号', 'logout', async () => {
      if (!await confirmAction('退出当前账号？', '插件将清除这个账号的本地登录信息。')) return
      await request('auth:logout'); await bootstrap()
    }, 'button ghost full-width'))
}
function modal(title, body) {
  const dialog = el('dialog', { class: 'dialog' }, el('div', { class: 'dialog-header' }, el('h2', {}, title),
    button('关闭', 'close', () => dialog.close(), 'icon-button')), body)
  document.body.append(dialog)
  dialog.addEventListener('close', () => dialog.remove(), { once: true })
  dialog.showModal()
  return dialog
}
function confirmAction(title, text) {
  return new Promise(resolve => {
    let confirmed = false
    const dialog = modal(title, el('div', {}, el('p', { class: 'muted' }, text), el('div', { class: 'dialog-actions' },
      button('取消', null, () => dialog.close(), 'button secondary'),
      button('确认', null, () => { confirmed = true; dialog.close() }, 'button primary'))))
    dialog.addEventListener('close', () => resolve(confirmed), { once: true })
  })
}
async function copy(value) {
  if (!value) return
  await navigator.clipboard.writeText(value); toast('已复制到剪贴板')
}
function formatDate(value, short = false) {
  if (!value) return ''
  const normalized = String(value).replace(' ', 'T')
  const date = new Date(/(?:Z|[+-]\d\d:\d\d)$/i.test(normalized) ? normalized : `${normalized}Z`)
  if (Number.isNaN(date.getTime())) return ''
  return date.toLocaleString('zh-CN', short ? { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }
    : { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false })
}
let bootId = 0
async function bootstrap() {
  const id = ++bootId
  const [auth, settings] = await Promise.all([request('auth:status'), request('settings:get')])
  if (id !== bootId) return
  ++state.generation
  state.auth = auth.auth; state.profiles = auth.profiles || []; state.settings = settings.settings
  state.accounts = []; state.messages = []; state.detail = null; state.draft = null; state.accountId = null
  state.view = 'inbox'; state.error = ''; state.loading = false
  render()
  if (state.auth && !state.addingLogin) await loadWorkspace()
}
let changeTimer
chrome.runtime.onMessage.addListener(message => {
  if (message.type === 'session:changed') {
    clearTimeout(changeTimer)
    changeTimer = setTimeout(() => run(async () => {
      const { auth } = await request('auth:status')
      if (auth?.id !== state.auth?.id) await bootstrap()
    }), 100)
  }
  // Do not replace inputs or scroll positions when a background poll completes.
  if (message.type === 'data:changed' && message.sessionId === state.auth?.id && !state.loading &&
    !state.detail && ['inbox', 'sent'].includes(state.view)) {
    const refresh = root.querySelector('.header-actions button:last-child')
    if (refresh) { refresh.classList.add('has-update'); refresh.title = '有新变化，点击刷新' }
  }
  return false
})
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.theme) { state.settings.theme = changes.theme.newValue; theme() }
})
root.replaceChildren(empty('正在打开 Xi-Mail', '你的随身邮箱即将就绪。', 'mail'))
void run(bootstrap)
