/** Xi-Mail 共享模块：供后台和面板复用的基础逻辑。 */
/**
 * 邮件正文处理：生成受限文档并从邮件文本中提取可靠验证码。
 */
function escapeText(value) {
  return value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
}

function documentShell(body) {
  // 文档头部和内嵌样式同样展开；正文边界不额外插入空白，保留邮件内容。
  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="referrer" content="no-referrer">
    <meta http-equiv="Content-Security-Policy"
      content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'">
    <style>
      /* 正文使用浅色底；页面主题不会覆盖邮件自身的排版。 */
      :root {
        color-scheme: light;
      }

      * {
        box-sizing: border-box;
        max-width: 100%;
      }

      body {
        margin: 0;
        padding: 16px;
        background: #fff;
        font: 16px/1.65 system-ui, sans-serif;
        color: #222;
        overflow-wrap: anywhere;
      }

      table {
        max-width: 100% !important;
      }

      pre {
        font: inherit;
        white-space: pre-wrap;
      }

      a {
        color: #1d4ed8;
      }
    </style>
  </head><body>${body}</body></html>`
}

function safeEmailDocument(html, text) {
  if (!html.trim()) return documentShell(`<pre>${escapeText(text)}</pre>`)
  const parsed = new DOMParser().parseFromString(html, 'text/html')
  parsed
    .querySelectorAll(
      'script,iframe,object,embed,form,input,button,textarea,select,base,meta,link,svg,math,video,audio,source'
    )
    .forEach((node) => node.remove())
  parsed.querySelectorAll('*').forEach((node) => {
    for (const attribute of Array.from(node.attributes)) {
      if (
        attribute.name.toLowerCase().startsWith('on') ||
        ['srcdoc', 'formaction', 'ping', 'srcset', 'background', 'action'].includes(
          attribute.name.toLowerCase()
        )
      )
        node.removeAttribute(attribute.name)
    }
  })
  parsed.querySelectorAll('img').forEach((node) => {
    const src = node.getAttribute('src') || ''
    if (
      src.length > 2_000_000 ||
      !/^data:image\/(?:png|jpeg|gif|webp);base64,[a-z\d+/=\s]+$/i.test(src)
    )
      node.remove()
  })
  parsed.querySelectorAll('a[href]').forEach((link) => {
    try {
      const url = new URL(link.getAttribute('href') || '')
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password)
        throw new Error('invalid link')
      link.href = url.href
      link.target = '_blank'
      link.rel = 'noopener noreferrer'
    } catch {
      link.removeAttribute('href')
    }
  })
  // 在同一 CSP 与沙箱内保留头部样式；继续阻止外部样式表和远程资源。
  const styles = Array.from(parsed.head.querySelectorAll('style'))
    .map((node) => node.outerHTML)
    .join('')
  return documentShell(styles + parsed.body.innerHTML)
}

function validCode(code) {
  return /^[a-z\d]{4,10}$/i.test(code) && /\d/.test(code)
}

function extractVerificationCode(code, text) {
  const supplied = typeof code === 'string' ? code.trim() : ''
  if (validCode(supplied)) return supplied
  if (typeof text !== 'string') return ''
  // 必须有明确的验证语境，避免把普通订单号或年份误识别为验证码。
  const pattern =
    /(?:验证码|校验码|动态码|安全码|登录码|verification(?:\s+code)?|one[- ]time(?:\s+(?:password|code))?|security\s+code|login\s+code|\botp\b|\bcode\s*[:：])[^a-z\d]{0,16}([a-z\d]{4,10})(?![a-z\d])/gi
  const english =
    /(?:verification\s+code|one[- ]time\s+(?:password|code)|security\s+code|login\s+code)\s*(?:is\s*)?[:：]?\s*([a-z\d]{4,10})(?![a-z\d])/gi
  for (const expression of [pattern, english]) {
    for (const match of text.matchAll(expression)) if (validCode(match[1])) return match[1]
  }
  return ''
}

/**
 * xi-mail API 客户端：定义接口数据、校验站点地址并统一处理请求及响应。
 */
// ── 2. 错误类型与地址校验 ──
class ApiError extends Error {
  code
  constructor(message, code) {
    super(message)
    this.name = 'ApiError'
    this.code = code
  }
}

/** 校验并规范化用户配置的站点地址：仅允许 https 与本地 http */
function normalizeOrigin(value) {
  if (typeof value !== 'string' || !value.trim()) return null
  try {
    const url = new URL(value.trim())
    const localHttp = url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname)
    if (url.protocol !== 'https:' && !localHttp) return null
    if (url.username || url.password) return null
    return url.origin
  } catch {
    return null
  }
}

/**
 * 附件下载 URL：移植后端 mail-vue cvtR2Url 逻辑——R2 公开域名 + key。
 * r2Domain 从 GET /setting/websiteConfig（免鉴权）获取。
 */
function attachmentUrl(r2Domain, attachment) {
  const key = attachment.key?.trim()
  if (!key) return ''
  try {
    if (/^https:\/\//i.test(key)) {
      const direct = new URL(key)
      return direct.username || direct.password ? '' : direct.href
    }
    if (/^[a-z][a-z\d+.-]*:/i.test(key) || key.startsWith('//')) return ''
    const domain = r2Domain.trim()
    if (!domain) return ''
    const base = new URL(domain.includes('://') ? domain : `https://${domain}`)
    if (!normalizeOrigin(base.href)) return ''
    const parts = key.replace(/^\/+/, '').split('/')
    if (parts.some((part) => part === '..' || part === '.')) return ''
    base.pathname = `${base.pathname.replace(/\/+$/, '')}/${parts.map(encodeURIComponent).join('/')}`
    base.search = ''
    base.hash = ''
    return base.href
  } catch {
    return ''
  }
}

/** xi-mail worker（index.js）要求 API 走 /api/ 前缀，否则落到静态资源处理器（405） */
const API_PREFIX = '/api'

// ── 3. 统一请求入口与业务接口 ──
class XiMailClient {
  origin
  token
  fetchImpl
  constructor(origin, token, fetchImpl) {
    const normalized = normalizeOrigin(origin)
    if (!normalized) throw new ApiError('无效的站点地址，仅支持 https 或本地 http。', 400)
    this.origin = normalized
    this.token = token
    this.fetchImpl = fetchImpl ?? ((input, init) => fetch(input, init))
  }
  async request(method, path, options) {
    const fullPath = path.startsWith('/') ? `${API_PREFIX}${path}` : `${API_PREFIX}/${path}`
    const url = new URL(fullPath, this.origin)
    if (options?.query) {
      for (const [key, value] of Object.entries(options.query)) {
        if (value !== undefined && value !== null) url.searchParams.set(key, String(value))
      }
    }
    const headers = { 'Content-Type': 'application/json', 'accept-language': 'zh' }
    if (this.token) headers.Authorization = this.token
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 20000)
    try {
      const response = await this.fetchImpl(url.toString(), {
        method,
        headers,
        signal: controller.signal,
        credentials: 'omit',
        redirect: 'error',
        cache: 'no-store',
        body: options?.json === undefined ? undefined : JSON.stringify(options.json),
      })
      if (response.status === 401) {
        throw new ApiError('登录已过期，请重新登录。', 401)
      }
      let payload = null
      try {
        payload = await response.json()
      } catch {
        throw new ApiError(`响应不是有效 JSON（HTTP ${response.status}）。`, response.status)
      }
      if (payload?.code === 401) throw new ApiError('登录已过期，请重新登录。', 401)
      if (response.ok && payload && payload.code === 200) return payload.data
      throw new ApiError(
        typeof payload?.message === 'string'
          ? payload.message
          : `请求失败（HTTP ${response.status}）。`,
        payload?.code ?? response.status
      )
    } catch (error) {
      if (error instanceof ApiError) throw error
      throw new ApiError(
        controller.signal.aborted
          ? '请求超时，请检查网络后重试。发信超时请先核实是否已发送。'
          : '无法连接邮箱站点，请检查地址、网络或站点访问限制。',
        503
      )
    } finally {
      clearTimeout(timer)
    }
  }
  /** 登录：响应 data 为 { token } 对象（login-api 的 result.ok({ token })），需取出 token 字段 */
  async login(email, password) {
    const data = await this.request('POST', '/login', {
      json: { email, password },
    })
    if (typeof data?.token !== 'string' || !data.token)
      throw new ApiError('登录响应不完整，请检查服务端版本。', 502)
    return data.token
  }
  async loginUserInfo() {
    const user = await this.request('GET', '/my/loginUserInfo')
    if (!user || typeof user.email !== 'string') throw new ApiError('用户信息响应不完整。', 502)
    return {
      userId: user.userId, email: user.email, name: user.name,
      account: user.account, permKeys: Array.isArray(user.permKeys) ? user.permKeys : [],
      role: user.role, type: user.type,
    }
  }
  websiteConfig() {
    return this.request('GET', '/setting/websiteConfig')
  }
  async accountList() {
    const result = []
    let cursor = { size: 30, accountId: 0, lastSort: 9999999999 }
    const seen = new Set()
    for (let page = 0; page < 100; page++) {
      const batch = await this.request('GET', '/account/list', { query: cursor })
      if (
        !Array.isArray(batch) ||
        batch.some(
          (a) =>
            !a ||
            !Number.isSafeInteger(a.accountId) ||
            a.accountId <= 0 ||
            typeof a.email !== 'string'
        )
      )
        throw new ApiError('邮箱列表格式不兼容。', 502)
      if (batch.some((a) => seen.has(a.accountId)))
        throw new ApiError('邮箱分页重复，请刷新后重试。', 502)
      batch.forEach((a) => {
        seen.add(a.accountId)
        result.push(a)
      })
      if (batch.length < 30) return result
      const last = batch[batch.length - 1]
      if (!Number.isFinite(last.sort)) throw new ApiError('邮箱排序字段缺失。', 502)
      cursor = { size: 30, accountId: last.accountId, lastSort: last.sort }
    }
    throw new ApiError('邮箱数量超过当前加载限制。', 413)
  }
  accountDelete(accountId) {
    return this.request('DELETE', '/account/delete', { query: { accountId } })
  }
  accountAdd(email) {
    return this.request('POST', '/account/add', { json: { email } })
  }
  async emailList(params) {
    const result = await this.request('GET', '/email/list', {
      query: { ...params, full: 1 },
    })
    if (
      !result ||
      !Array.isArray(result.list) ||
      !Number.isFinite(result.total) ||
      result.list.some(
        (m) => !m || !Number.isSafeInteger(m.emailId) || !Number.isSafeInteger(m.accountId)
      )
    )
      throw new ApiError('邮件列表格式不兼容，请检查站点版本。', 502)
    return result
  }
  /** 增量查询：返回 emailId 大于 lastEmailId 的邮件（最多 20 封，含正文列） */
  async emailLatest(params) {
    const list = await this.request('GET', '/email/latest', {
      query: { emailId: 0, ...params },
    })
    if (!Array.isArray(list) || list.some((m) => !m || !Number.isSafeInteger(m.emailId)))
      throw new ApiError('最新邮件响应格式不兼容。', 502)
    return list
  }
  emailRead(emailIds) {
    return this.request('PUT', '/email/read', { json: { emailIds } })
  }
  async emailContent(emailId) {
    const data = await this.request('GET', '/email/content', { query: { emailId } })
    if (!data || data.emailId !== emailId) throw new ApiError('邮件正文响应不完整。', 502)
    return data
  }
  emailDelete(emailIds) {
    return this.request('DELETE', '/email/delete', {
      query: { emailIds: emailIds.join(',') },
    })
  }
  emailSend(params) {
    return this.request('POST', '/email/send', { json: params })
  }
  attList(emailId) {
    return this.request('GET', '/email/attList', { query: { emailId } })
  }
}

/**
 * 扩展设置：校验本地配置，合并编辑结果并协调远端更新。
 */
const DEFAULT_SETTINGS = {
  apiOrigin: '',
  theme: 'system',
  floatEnabled: true,
  pollEnabled: true,
  pollIntervalMinutes: 1,
}
const MIN_POLL_INTERVAL_MINUTES = 0.5

function settingsPatch(base, draft) {
  return Object.fromEntries(
    Object.keys(DEFAULT_SETTINGS)
      .filter((key) => base[key] !== draft[key])
      .map((key) => [key, draft[key]])
  )
}

function rebaseSettings(base, draft, remote) {
  const dirty = Object.keys(settingsPatch(base, draft))
  return {
    base: { ...remote, ...Object.fromEntries(dirty.map((key) => [key, base[key]])) },
    draft: { ...remote, ...Object.fromEntries(dirty.map((key) => [key, draft[key]])) },
  }
}

function clampInterval(value) {
  const parsed = Number(value)
  if (!Number.isFinite(parsed)) return DEFAULT_SETTINGS.pollIntervalMinutes
  return Math.min(60, Math.max(parsed, MIN_POLL_INTERVAL_MINUTES))
}

async function loadSettings(storage) {
  const stored = await storage.get(Object.keys(DEFAULT_SETTINGS))
  return {
    apiOrigin: typeof stored.apiOrigin === 'string' ? stored.apiOrigin : DEFAULT_SETTINGS.apiOrigin,
    theme: ['system', 'light', 'dark'].includes(String(stored.theme))
      ? stored.theme
      : DEFAULT_SETTINGS.theme,
    floatEnabled:
      stored.floatEnabled === undefined
        ? DEFAULT_SETTINGS.floatEnabled
        : Boolean(stored.floatEnabled),
    pollEnabled:
      stored.pollEnabled === undefined ? DEFAULT_SETTINGS.pollEnabled : Boolean(stored.pollEnabled),
    pollIntervalMinutes: clampInterval(stored.pollIntervalMinutes),
  }
}

async function saveSettings(storage, settings) {
  await storage.set({
    apiOrigin: settings.apiOrigin,
    theme: settings.theme,
    floatEnabled: settings.floatEnabled,
    pollEnabled: settings.pollEnabled,
    pollIntervalMinutes: clampInterval(settings.pollIntervalMinutes),
  })
}

function chromeLocalStorage() {
  return {
    get: (keys) => chrome.storage.local.get(keys),
    set: (items) => chrome.storage.local.set(items),
  }
}

export {
  ApiError,
  XiMailClient,
  DEFAULT_SETTINGS,
  MIN_POLL_INTERVAL_MINUTES,
  attachmentUrl,
  chromeLocalStorage,
  extractVerificationCode,
  loadSettings,
  normalizeOrigin,
  rebaseSettings,
  safeEmailDocument,
  saveSettings,
  settingsPatch,
}
