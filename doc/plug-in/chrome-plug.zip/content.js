/** Xi-Mail 网页悬浮入口：主题、布局、拖动与网页填充。 */
;(function () {
  'use strict'

  /**
   * 网页填充：定位可见的邮箱或验证码输入框，并派发页面可识别的输入事件。
   */
  function visible(input) {
    if (
      input.matches(':disabled') ||
      input.readOnly ||
      input.type === 'hidden' ||
      !input.isConnected
    )
      return false
    let ancestor = input
    while (ancestor) {
      if (ancestor.matches('[inert], [aria-hidden="true"]')) return false
      const root = ancestor.getRootNode()
      ancestor =
        ancestor.assignedSlot ||
        ancestor.parentElement ||
        (root instanceof ShadowRoot ? root.host : null)
    }
    if (!input.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) return false
    const rect = input.getBoundingClientRect()
    return rect.width > 0 && rect.height > 0
  }

  function description(input) {
    return [
      input.name,
      input.id,
      input.placeholder,
      input.autocomplete,
      input.getAttribute('aria-label'),
      ...Array.from(input.labels || []).map((label) => label.textContent),
    ].join(' ')
  }

  function matches(input, kind) {
    if (kind === 'email')
      return (
        ['email', 'text'].includes(input.type) &&
        (input.type === 'email' || /(?:e-?mail|邮箱)/i.test(description(input)))
      )
    if (!['text', 'tel', 'number', 'password'].includes(input.type)) return false
    const codeName = [input.name, input.id].some((name) =>
      /^(?:code|otp|passcode|(?:verification|verify|security|auth|login|email|sms)[_-]?code)(?:[_-]?\d+)?$/i.test(
        name
      )
    )
    return (
      codeName ||
      input.autocomplete === 'one-time-code' ||
      /验证码|校验码|动态码|安全码|登录码|verification|one[- ]time|passcode|\botp\b/i.test(
        description(input)
      )
    )
  }

  function inputs(root) {
    const found = Array.from(root.querySelectorAll('input'))
    for (const element of root.querySelectorAll('*'))
      if (element.shadowRoot) found.push(...inputs(element.shadowRoot))
    return found
  }

  function setValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set
    if (setter) setter.call(input, value)
    else input.value = value
    input.dispatchEvent(new Event('input', { bubbles: true, composed: true }))
    input.dispatchEvent(new Event('change', { bubbles: true, composed: true }))
  }

  function splitGroup(input) {
    if (input.maxLength !== 1) return []
    let parent = input.parentElement
    for (let level = 0; parent && level < 4; level++, parent = parent.parentElement) {
      const group = inputs(parent).filter(visible)
      if (
        group.length >= 4 &&
        group.length <= 10 &&
        group.every(
          (item) =>
            item.maxLength === 1 && ['text', 'tel', 'number', 'password'].includes(item.type)
        )
      )
        return group
      if (group.length > 10) break
    }
    return []
  }

  function fillPageValue(document, lastFocusedInput, kind, value) {
    if (!value) return { ok: false, error: '没有可填充的内容。' }
    const candidates = inputs(document).filter((input) => visible(input) && matches(input, kind))
    const focused =
      lastFocusedInput &&
      lastFocusedInput.ownerDocument === document &&
      visible(lastFocusedInput) &&
      (matches(lastFocusedInput, kind) ||
        (kind === 'verification-code' && splitGroup(lastFocusedInput).length > 0))
        ? lastFocusedInput
        : null
    const input = focused || (candidates.length === 1 ? candidates[0] : null)
    let group = kind === 'verification-code' && input ? splitGroup(input) : []
    if (!input && kind === 'verification-code' && candidates.length) {
      const proposed = splitGroup(candidates[0])
      if (proposed.length && candidates.every((item) => proposed.includes(item))) group = proposed
    }
    if (group.length) {
      if (group.length !== value.length)
        return { ok: false, error: '验证码长度与分格输入框数量不符，请手动核对。' }
      if (group.some((item, index) => item.type === 'number' && !/^\d$/.test(value[index])))
        return { ok: false, error: '数字输入框不能接收含字母的验证码，请手动核对。' }
      group.forEach((item, index) => setValue(item, value[index]))
      group[group.length - 1].focus()
      return { ok: true }
    }
    if (!input)
      return {
        ok: false,
        error:
          candidates.length > 1
            ? '检测到多个输入框，请先点击要填入的目标。'
            : '没有找到可填充的输入框；子框架或特殊组件可能需要手动粘贴。',
      }
    if (input.maxLength > 0 && value.length > input.maxLength)
      return { ok: false, error: '内容长度超过输入框限制，请手动核对。' }
    if (input.type === 'number' && !/^\d+$/.test(value))
      return { ok: false, error: '数字输入框不能接收含字母的验证码，请手动核对。' }
    setValue(input, value)
    input.focus()
    return { ok: true }
  }

  /**
   * 扩展设置：校验本地配置，合并编辑结果并协调远端更新。
   */
  const DEFAULT_SETTINGS = {
    apiOrigin: '',
    theme: 'system',
    floatEnabled: true,
    pollEnabled: true,
    pollIntervalMinutes: 1,
  }
  const MIN_POLL_INTERVAL_MINUTES = 0.5

  function clampInterval(value) {
    const parsed = Number(value)
    if (!Number.isFinite(parsed)) return DEFAULT_SETTINGS.pollIntervalMinutes
    return Math.min(60, Math.max(parsed, MIN_POLL_INTERVAL_MINUTES))
  }

  async function loadSettings(storage) {
    const stored = await storage.get(Object.keys(DEFAULT_SETTINGS))
    return {
      apiOrigin:
        typeof stored.apiOrigin === 'string' ? stored.apiOrigin : DEFAULT_SETTINGS.apiOrigin,
      theme: ['system', 'light', 'dark'].includes(String(stored.theme))
        ? stored.theme
        : DEFAULT_SETTINGS.theme,
      floatEnabled:
        stored.floatEnabled === undefined
          ? DEFAULT_SETTINGS.floatEnabled
          : Boolean(stored.floatEnabled),
      pollEnabled:
        stored.pollEnabled === undefined
          ? DEFAULT_SETTINGS.pollEnabled
          : Boolean(stored.pollEnabled),
      pollIntervalMinutes: clampInterval(stored.pollIntervalMinutes),
    }
  }

  function chromeLocalStorage() {
    return {
      get: (keys) => chrome.storage.local.get(keys),
      set: (items) => chrome.storage.local.set(items),
    }
  }

  /**
   * 网页悬浮入口：创建隔离外壳，处理拖动、主题同步和网页填充。
   * 重复注入时先清理旧控制器；面板内容由扩展页面承载。
   */
  ;(() => {
    const key = '__ximailFloatController'
    const scope = window
    scope[key]?.dispose?.()
    const cleanups = []
    let disposed = false
    let host = null
    let shadow = null
    let button = null
    let panel = null
    let frame = null
    let assigned = false
    let shown = false
    let lastInput = null
    let restoreFocus = null
    let position = null
    let panelPosition = null
    let launcherDragging = false
    let settings = null
    let requestVersion = 0
    const media = window.matchMedia('(prefers-color-scheme: dark)')
    const panelUrl = chrome.runtime.getURL('panel.html#float')

    // ── 1. 外壳生命周期 ──
    function destroyUi() {
      host?.remove()
      host = null
      shadow = null
      button = null
      panel = null
      frame = null
      shown = false
      assigned = false
      launcherDragging = false
    }

    const controller = {
      dispose() {
        disposed = true
        cleanups.splice(0).forEach((cleanup) => cleanup())
        destroyUi()
        if (scope[key] === controller) delete scope[key]
      },
    }
    scope[key] = controller

    // ── 2. 主题与视口布局 ──
    function applyTheme() {
      if (host && settings)
        host.dataset.theme =
          settings.theme === 'system' ? (media.matches ? 'dark' : 'light') : settings.theme
    }

    function layout() {
      if (!button || !panel) return
      // Root client dimensions exclude classic scrollbars; innerWidth/Height
      // include their space and would place part of the launcher underneath.
      const width = document.documentElement.clientWidth || window.innerWidth
      const height = document.documentElement.clientHeight || window.innerHeight
      const buttonSize = parseFloat(getComputedStyle(button).width) || 40
      const p = position || { left: width - 72, top: height - 72 }
      position = {
        left: launcherDragging ? Math.max(0, Math.min(p.left, width - buttonSize)) : Math.max(0, width - buttonSize),
        top: Math.max(8, Math.min(p.top, height - buttonSize - 8)),
      }
      button.style.left = `${position.left}px`
      button.style.top = `${position.top}px`
      const panelWidth = Math.min(480, Math.max(240, width - 16))
      const panelHeight = Math.min(680, Math.max(180, height - 80))
      const actualWidth = Math.min(panelWidth, width - 16)
      const actualHeight = Math.min(panelHeight, height - 16)
      // Open near the docked launcher until the user positions the window.
      const anchor = panelPosition || { left: position.left + buttonSize - actualWidth, top: position.top }
      const left = Math.max(8, Math.min(anchor.left, width - actualWidth - 8))
      const top = Math.max(8, Math.min(anchor.top, height - actualHeight - 8))
      if (panelPosition) panelPosition = { left, top }
      panel.style.width = `${actualWidth}px`
      panel.style.height = `${actualHeight}px`
      panel.style.left = `${left}px`
      panel.style.top = `${top}px`
    }

    // ── 3. 面板显隐与焦点恢复 ──
    function hide() {
      shown = false
      if (panel) panel.hidden = true
      if (button) {
        button.hidden = false
        button.setAttribute('aria-expanded', 'false')
      }
      if (restoreFocus?.isConnected) restoreFocus.focus({ preventScroll: true })
    }

    function show() {
      if (!panel || !frame || !button) return
      restoreFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null
      // about:blank 的加载不代表已设置扩展页面地址，需单独记录。
      if (!assigned) {
        assigned = true
        frame.src = panelUrl
      }
      shown = true
      panel.hidden = false
      button.hidden = true
      button.setAttribute('aria-expanded', 'true')
      layout()
      if (!panelPosition) panelPosition = { left: parseFloat(panel.style.left), top: parseFloat(panel.style.top) }
      frame.focus()
    }

    // ── 4. Shadow DOM 与拖动交互 ──
    function buildUi() {
      if (host || disposed) return
      host = document.createElement('div')
      host.style.setProperty('all', 'initial', 'important')
      host.style.setProperty('position', 'static', 'important')
      document.documentElement.appendChild(host)
      shadow = host.attachShadow({ mode: 'closed' })
      const css = document.createElement('link')
      css.rel = 'stylesheet'
      css.href = chrome.runtime.getURL('content.css')
      shadow.appendChild(css)
      button = document.createElement('button')
      button.type = 'button'
      button.className = 'ximail-float-btn'
      button.title = 'Xi-Mail：点击打开，拖动调整位置'
      button.setAttribute('aria-label', '打开 Xi-Mail 邮箱')
      button.setAttribute('aria-expanded', 'false')
      button.innerHTML =
        '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/></svg>'
      panel = document.createElement('div')
      panel.className = 'ximail-float-panel'
      panel.hidden = true
      panel.setAttribute('role', 'dialog')
      panel.setAttribute('aria-label', 'Xi-Mail 邮箱面板')
      const header = document.createElement('div')
      header.className = 'ximail-float-header'
      header.title = '拖动标题栏移动窗口'
      const title = document.createElement('span')
      title.textContent = 'Xi-Mail'
      const close = document.createElement('button')
      close.type = 'button'
      close.className = 'ximail-float-close'
      close.textContent = '×'
      close.setAttribute('aria-label', '关闭邮箱面板')
      close.addEventListener('click', hide)
      header.append(title, close)
      const grip = document.createElement('span')
      grip.className = 'ximail-drag-grip'
      grip.setAttribute('aria-hidden', 'true')
      grip.textContent = '⠿'
      header.insertBefore(grip, close)
      frame = document.createElement('iframe')
      frame.className = 'ximail-float-frame'
      frame.title = 'Xi-Mail 邮箱'
      frame.allow = 'clipboard-write'
      panel.append(header, frame)
      shadow.append(button, panel)
      // Capture the pointer on the title bar so dragging keeps working over
      // the iframe. The window never changes the launcher's docked position.
      let windowDrag = null
      header.addEventListener('pointerdown', event => {
        if (event.button !== 0 || event.target.closest('button')) return
        const rect = panel.getBoundingClientRect()
        windowDrag = { id: event.pointerId, x: event.clientX, y: event.clientY, left: rect.left, top: rect.top, moved: false }
        header.setPointerCapture(event.pointerId)
        panel.classList.add('is-dragging')
        event.preventDefault()
      })
      header.addEventListener('pointermove', event => {
        if (!windowDrag || event.pointerId !== windowDrag.id) return
        const dx = event.clientX - windowDrag.x
        const dy = event.clientY - windowDrag.y
        if (!windowDrag.moved && Math.hypot(dx, dy) < 3) return
        windowDrag.moved = true
        panelPosition = { left: windowDrag.left + dx, top: windowDrag.top + dy }
        layout()
      })
      const finishWindowDrag = () => {
        if (windowDrag?.moved && panelPosition)
          void chrome.storage.local.set({ floatPanelPosition: panelPosition }).catch(() => {})
        windowDrag = null
        panel.classList.remove('is-dragging')
      }
      header.addEventListener('pointerup', finishWindowDrag)
      header.addEventListener('pointercancel', finishWindowDrag)
      header.addEventListener('lostpointercapture', finishWindowDrag)
      let drag = null
      let suppressClick = false
      button.addEventListener('pointerdown', (event) => {
        if (event.button !== 0 || !button || shown) return
        const rect = button.getBoundingClientRect()
        drag = {
          id: event.pointerId,
          x: event.clientX,
          y: event.clientY,
          left: rect.left,
          top: rect.top,
          moved: false,
        }
        suppressClick = false
        button.setPointerCapture(event.pointerId)
      })
      button.addEventListener('pointermove', (event) => {
        if (!drag || event.pointerId !== drag.id) return
        const dx = event.clientX - drag.x
        const dy = event.clientY - drag.y
        if (!drag.moved && Math.hypot(dx, dy) < 5) return
        if (!drag.moved) {
          panelPosition = null
          void chrome.storage.local.remove('floatPanelPosition').catch(() => {})
        }
        drag.moved = true
        launcherDragging = true
        button.classList.add('is-dragging')
        suppressClick = true
        position = { left: drag.left + dx, top: drag.top + dy }
        layout()
      })
      const finishDrag = () => {
        launcherDragging = false
        button.classList.remove('is-dragging')
        layout()
        if (drag?.moved && position)
          void chrome.storage.local.set({ floatPosition: position }).catch(() => {})
        drag = null
      }
      button.addEventListener('pointerup', finishDrag)
      button.addEventListener('pointercancel', finishDrag)
      button.addEventListener('lostpointercapture', finishDrag)
      button.addEventListener('click', (event) => {
        event.preventDefault()
        event.stopPropagation()
        if (suppressClick) {
          suppressClick = false
          return
        }
        if (shown) hide()
        else show()
      })
      applyTheme()
      layout()
    }

    // ── 5. 设置同步与全局事件 ──
    async function reloadSettings() {
      const version = ++requestVersion
      try {
        const loaded = await loadSettings(chromeLocalStorage())
        if (disposed || version !== requestVersion) return
        settings = loaded
        if (!settings.floatEnabled) {
          if (shown) hide()
          destroyUi()
        } else {
          buildUi()
          applyTheme()
        }
      } catch {
        /* 扩展重载后旧页面仍可使用，刷新页面时重新注入。 */
      }
    }

    const focus = (event) => {
      const input = event.composedPath().find((item) => item instanceof HTMLInputElement)
      if (input instanceof HTMLInputElement) lastInput = input
    }
    document.addEventListener('focusin', focus, true)
    cleanups.push(() => document.removeEventListener('focusin', focus, true))
    const escape = (event) => {
      if (event.key === 'Escape' && shown) {
        hide()
        event.stopPropagation()
      }
    }
    document.addEventListener('keydown', escape, true)
    cleanups.push(() => document.removeEventListener('keydown', escape, true))
    const message = (event) => {
      const origins = [new URL(panelUrl).origin, `chrome-extension://${chrome.runtime.id}`]
      if (
        event.source === frame?.contentWindow &&
        origins.includes(event.origin) &&
        event.data?.type === 'ximail:close'
      )
        hide()
    }
    window.addEventListener('message', message)
    cleanups.push(() => window.removeEventListener('message', message))
    const runtimeMessage = (value, sender, respond) => {
      if (sender.id !== chrome.runtime.id || !value || typeof value !== 'object') return false
      const op = value
      if (op.type !== 'fill:apply') return false
      if ((op.kind !== 'email' && op.kind !== 'verification-code') || typeof op.value !== 'string')
        return false
      respond(fillPageValue(document, lastInput, op.kind, op.value))
      return false
    }
    chrome.runtime.onMessage.addListener(runtimeMessage)
    cleanups.push(() => chrome.runtime.onMessage.removeListener(runtimeMessage))
    const storage = (changes, area) => {
      if (area === 'local' && (changes.floatEnabled || changes.theme)) void reloadSettings()
    }
    chrome.storage.onChanged.addListener(storage)
    cleanups.push(() => chrome.storage.onChanged.removeListener(storage))
    window.addEventListener('resize', layout)
    cleanups.push(() => window.removeEventListener('resize', layout))
    // A page can gain or lose its scrollbar without a browser-window resize.
    const viewportObserver = new ResizeObserver(layout)
    viewportObserver.observe(document.documentElement)
    cleanups.push(() => viewportObserver.disconnect())
    media.addEventListener('change', applyTheme)
    cleanups.push(() => media.removeEventListener('change', applyTheme))
    void chrome.storage.local
      .get(['floatPosition', 'floatPanelPosition'])
      .then((stored) => {
        if (disposed) return
        const saved = stored.floatPosition
        if (
          saved &&
          typeof saved.left === 'number' &&
          typeof saved.top === 'number' &&
          Number.isFinite(saved.left) &&
          Number.isFinite(saved.top)
        )
          position = { left: saved.left, top: saved.top }
        const savedPanel = stored.floatPanelPosition
        if (savedPanel && Number.isFinite(savedPanel.left) && Number.isFinite(savedPanel.top))
          panelPosition = { left: savedPanel.left, top: savedPanel.top }
        layout()
      })
      .catch(() => {})
    void reloadSettings()
  })()
})()
